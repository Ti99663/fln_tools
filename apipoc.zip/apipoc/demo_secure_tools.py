"""
安全工具系统的简化演示 - 展示核心概念
"""

from secure_tools import (
    ToolContext, User, PermissionLevel, ActionType,
    GetUserBookingsTool, CancelBookingTool
)

print("\n" + "="*80)
print("🔐 安全工具系统演示 - 核心安全特性")
print("="*80)

# ============================================================================
# 演示1：普通用户查询自己的数据（成功）
# ============================================================================
print("\n【演示1】普通用户查询自己的预订 ✓")
print("-"*80)

user = User(
    id="user_123",
    name="张三",
    role="customer",
    permission_level=PermissionLevel.USER
)

context = ToolContext(
    user=user,
    data_source_config={"type": "mysql", "database": "restaurant_db"}
)

tool = GetUserBookingsTool()
try:
    result = tool.execute(context, {"user_id": "user_123"})
    print(f"\n✓ 成功查询到 {result['count']} 个预订")
except Exception as e:
    print(f"✗ 查询失败: {e}")

print("\n📋 审计日志摘要:")
if context.audit_log:
    log = context.audit_log[0]
    print(f"  操作: {log['action'].upper()} | 状态: {log['status']}")

# ============================================================================
# 演示2：普通用户尝试查询他人数据（被拒绝）
# ============================================================================
print("\n\n【演示2】普通用户尝试查询他人数据 ✗")
print("-"*80)

context2 = ToolContext(
    user=user,
    data_source_config={"type": "mysql"}
)

try:
    result = tool.execute(context2, {"user_id": "user_456"})  # 不是用户自己
    print(f"\n✗ 不应该成功！")
except PermissionError as e:
    print(f"\n✓ 正确被拒绝: {e}")

print("\n📋 审计日志摘要:")
if context2.audit_log:
    log = context2.audit_log[-1]
    print(f"  操作: {log['action'].upper()} | 状态: {log['status']}")
    if log.get('details', {}).get('error'):
        print(f"  原因: {log['details']['error']}")

# ============================================================================
# 演示3：普通用户尝试取消预订（权限不足）
# ============================================================================
print("\n\n【演示3】普通用户尝试取消预订（权限不足）✗")
print("-"*80)

context3 = ToolContext(
    user=user,
    data_source_config={"type": "mysql"}
)

cancel_tool = CancelBookingTool()

try:
    result = cancel_tool.execute(context3, {
        "booking_id": "book_001",
        "user_id": "user_123"
    })
    print(f"\n✗ 不应该成功！")
except PermissionError as e:
    print(f"\n✓ 正确被拒绝: {e}")

print("\n📋 审计日志摘要:")
if context3.audit_log:
    log = context3.audit_log[-1]  # 最后一条记录权限问题
    print(f"  操作: {log['action'].upper()} | 状态: {log['status']}")
    if log.get('details', {}).get('error'):
        print(f"  原因: {log['details']['error']}")

# ============================================================================
# 演示4：管理员可以取消任何预订（成功）
# ============================================================================
print("\n\n【演示4】管理员成功取消预订 ✓")
print("-"*80)

admin = User(
    id="admin_001",
    name="李四",
    role="admin",
    permission_level=PermissionLevel.ADMIN
)

context4 = ToolContext(
    user=admin,
    data_source_config={"type": "mysql"}
)

try:
    result = cancel_tool.execute(context4, {
        "booking_id": "book_001",
        "user_id": "user_123"  # 可以取消别人的
    })
    print(f"\n✓ 取消成功 ({result['affected_rows']} 条记录被更新)")
except Exception as e:
    print(f"✗ 取消失败: {e}")

print("\n📋 审计日志摘要:")
if context4.audit_log:
    log = context4.audit_log[-1]
    print(f"  操作: {log['action'].upper()} | 状态: {log['status']}")

# ============================================================================
# 演示5：主持人可以管理用户预订（成功）
# ============================================================================
print("\n\n【演示5】主持人取消用户预订 ✓")
print("-"*80)

moderator = User(
    id="mod_001",
    name="王五",
    role="moderator",
    permission_level=PermissionLevel.MODERATOR
)

context5 = ToolContext(
    user=moderator,
    data_source_config={"type": "mysql"}
)

try:
    result = cancel_tool.execute(context5, {
        "booking_id": "book_002",
        "user_id": "user_123"
    })
    print(f"\n✓ 成功取消用户的预订")
except Exception as e:
    print(f"✗ 失败: {e}")

print("\n📋 审计日志摘要:")
if context5.audit_log:
    log = context5.audit_log[-1]
    print(f"  操作: {log['action'].upper()} | 状态: {log['status']}")

# ============================================================================
# 总结
# ============================================================================
print("\n\n" + "="*80)
print("✨ 演示总结")
print("="*80)

print("""
✅ 实现的安全特性：

1. 权限检查 (PermissionLevel)
   ✓ USER (10) 只能基础操作
   ✓ MODERATOR (50) 可以管理用户
   ✓ ADMIN (100) 完全访问

2. 所有权验证 (Preconditions)
   ✓ 普通用户只能查询自己的数据
   ✓ 管理员可以查询任何人的数据

3. 状态验证 (Preconditions)
   ✓ 不能取消已完成的预订
   ✓ 不能重复取消已删除的预订

4. 审计日志 (Audit Trail)
   ✓ 记录所有操作（成功✓/失败✗/拒绝⊘）
   ✓ 包含用户、时间、操作类型
   ✓ 记录错误原因供后期调查

5. 数据源抽象
   ✓ 工具不依赖具体数据库
   ✓ 支持通过配置切换数据源
   ✓ 提前为多元化做好准备

🔐 三层安全模型：
   层1：权限检查  → 用户有没有权限执行这个操作？
   层2：前置条件  → 数据状态是否允许操作？
   层3：审计日志  → 谁做了什么，什么时候，结果怎样？

💡 关键洞察：
   • 同一个工具在不同权限下表现不同
   • 安全检查集中在SecureTool基类中（DRY原则）
   • 具体的业务逻辑在前置条件中（易于扩展）
   • 审计日志完整记录每一步（符合合规要求）
""")

print("\n")
