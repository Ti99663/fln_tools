"""
区分操作类型和对应的安全策略

根据操作对象的性质，采用不同的验证和处理方案
"""

from enum import Enum
from typing import Dict, Any, List
from dataclasses import dataclass


# ============================================================================
# Part 1: 操作类型分类
# ============================================================================

class DataOwnershipType(Enum):
    """数据所有权类型"""
    PRIVATE = "private"        # 私人数据：用户个人信息
    SHARED = "shared"          # 共享数据：如预订时间槽
    PUBLIC = "public"          # 公共数据：系统级别信息


class OperationType(Enum):
    """操作类型和对应的策略"""
    
    # 私人数据操作 - 只需身份验证
    MODIFY_PERSONAL_INFO = "modify_personal_info"      # 修改自己的信息
    VIEW_PERSONAL_DATA = "view_personal_data"          # 查看自己的数据
    DELETE_PERSONAL_DATA = "delete_personal_data"      # 删除自己的数据
    
    # 共享资源操作 - 需要状态变更，记录原因
    CANCEL_BOOKING = "cancel_booking"                  # 取消预订
    RELEASE_RESOURCE = "release_resource"              # 释放资源
    PAUSE_SERVICE = "pause_service"                    # 暂停服务
    
    # 公共数据操作 - 需要审核流程
    MODIFY_RESTAURANT_INFO = "modify_restaurant_info"  # 修改餐厅信息
    CREATE_PROMOTION = "create_promotion"              # 创建促销活动
    APPROVE_LISTING = "approve_listing"                # 审核列表


# ============================================================================
# Part 2: 操作的安全策略定义
# ============================================================================

@dataclass
class OperationSecurityPolicy:
    """定义每类操作的安全策略"""
    
    operation_type: OperationType
    data_ownership: DataOwnershipType
    requires_identity_verification: bool    # 身份验证
    requires_ownership_check: bool         # 所有权检查
    requires_status_validation: bool       # 状态检查
    requires_audit_reason: bool            # 需要记录原因
    allows_direct_deletion: bool           # 是否允许直接删除
    requires_approval_workflow: bool       # 需要审核流程
    
    def __str__(self):
        checks = []
        if self.requires_identity_verification:
            checks.append("身份验证")
        if self.requires_ownership_check:
            checks.append("所有权检查")
        if self.requires_status_validation:
            checks.append("状态验证")
        if self.requires_audit_reason:
            checks.append("记录原因")
        if self.requires_approval_workflow:
            checks.append("审核流程")
        return " → ".join(checks)


# ============================================================================
# Part 3: 操作策略库
# ============================================================================

OPERATION_POLICIES = {
    # 私人数据操作 - 最少干预
    OperationType.MODIFY_PERSONAL_INFO: OperationSecurityPolicy(
        operation_type=OperationType.MODIFY_PERSONAL_INFO,
        data_ownership=DataOwnershipType.PRIVATE,
        requires_identity_verification=True,    # ✓ 验证是否本人
        requires_ownership_check=True,          # ✓ 必须是自己的数据
        requires_status_validation=False,       # ✗ 不需要
        requires_audit_reason=False,            # ✗ 不需要
        allows_direct_deletion=True,            # ✓ 可以直接删除自己的数据
        requires_approval_workflow=False        # ✗ 不需要
    ),
    
    # 共享资源操作 - 状态变更 + 原因记录
    OperationType.CANCEL_BOOKING: OperationSecurityPolicy(
        operation_type=OperationType.CANCEL_BOOKING,
        data_ownership=DataOwnershipType.SHARED,
        requires_identity_verification=True,    # ✓ 验证身份
        requires_ownership_check=True,          # ✓ 检查是否是自己的预订
        requires_status_validation=True,        # ✓ 检查预订状态（不能重复取消）
        requires_audit_reason=True,             # ✓ 记录取消原因
        allows_direct_deletion=False,           # ✗ 不直接删除，标记为取消
        requires_approval_workflow=False        # ✗ 用户自己可以取消
    ),
    
    # 公共数据操作 - 完整审核流程
    OperationType.MODIFY_RESTAURANT_INFO: OperationSecurityPolicy(
        operation_type=OperationType.MODIFY_RESTAURANT_INFO,
        data_ownership=DataOwnershipType.PUBLIC,
        requires_identity_verification=True,    # ✓ 验证身份
        requires_ownership_check=True,          # ✓ 检查是否餐厅所有者
        requires_status_validation=True,        # ✓ 检查餐厅状态
        requires_audit_reason=True,             # ✓ 记录修改原因
        allows_direct_deletion=False,           # ✗ 不直接删除
        requires_approval_workflow=True         # ✓ 需要管理员审核
    ),
}


# ============================================================================
# Part 4: 具体实现示例
# ============================================================================

class PrivateDataOperation:
    """私人数据操作 - 修改用户个人信息"""
    
    @staticmethod
    def execute(user_id: str, current_user_id: str, updates: Dict[str, Any]):
        """
        用户修改自己的个人信息
        
        策略：
        1. 身份验证 ✓
        2. 所有权检查 ✓
        3. 直接更新 ✓
        """
        policy = OPERATION_POLICIES[OperationType.MODIFY_PERSONAL_INFO]
        
        print(f"【私人数据操作】修改用户信息")
        print(f"策略: {policy}")
        print()
        
        # 步骤1：身份验证 ✓
        print("  [步骤1] 身份验证")
        if not current_user_id:
            raise PermissionError("未登录，无法修改")
        print(f"    ✓ 用户已登录: {current_user_id}")
        print()
        
        # 步骤2：所有权检查 ✓
        print("  [步骤2] 所有权检查")
        if user_id != current_user_id:
            raise PermissionError(f"无法修改其他用户的信息")
        print(f"    ✓ 所有权验证通过 (修改自己的数据)")
        print()
        
        # 步骤3：直接更新 ✓
        print("  [步骤3] 更新数据")
        print(f"    ✓ 更新字段: {list(updates.keys())}")
        print()
        
        # 无需记录原因、无需审核流程
        return {
            "success": True,
            "message": "个人信息已更新",
            "updates": updates
        }


class SharedResourceOperation:
    """共享资源操作 - 取消预订"""
    
    @staticmethod
    def execute(booking_id: str, user_id: str, current_user_id: str, reason: str):
        """
        用户取消自己的预订
        
        策略：
        1. 身份验证 ✓
        2. 所有权检查 ✓
        3. 状态验证 ✓
        4. 标记状态 ✓ （不是删除！）
        5. 记录原因 ✓
        """
        policy = OPERATION_POLICIES[OperationType.CANCEL_BOOKING]
        
        print(f"【共享资源操作】取消预订")
        print(f"策略: {policy}")
        print()
        
        # 步骤1：身份验证
        print("  [步骤1] 身份验证")
        if not current_user_id:
            raise PermissionError("未登录")
        print(f"    ✓ 用户已登录: {current_user_id}")
        print()
        
        # 步骤2：所有权检查
        print("  [步骤2] 所有权检查")
        if user_id != current_user_id:
            raise PermissionError("只能取消自己的预订")
        print(f"    ✓ 预订所有者验证通过")
        print()
        
        # 步骤3：状态验证
        print("  [步骤3] 预订状态验证")
        # 模拟获取预订状态
        booking_status = "confirmed"  # 可能的值: confirmed, cancelled, completed
        if booking_status == "cancelled":
            raise ValueError("预订已被取消，无法重复取消")
        if booking_status == "completed":
            raise ValueError("预订已完成，无法取消")
        print(f"    ✓ 预订状态有效 (当前: {booking_status})")
        print()
        
        # 步骤4：标记状态（不是删除）
        print("  [步骤4] 更新预订状态")
        print(f"    ✓ 更新字段:")
        print(f"      - status: confirmed → cancelled")
        print(f"      - cancel_reason: '{reason}'")
        print(f"      - cancelled_at: 2026-03-27T17:54:00")
        print()
        
        # 步骤5：记录审计日志
        print("  [步骤5] 记录审计日志")
        print(f"    ✓ 操作类型: CANCEL_BOOKING")
        print(f"    ✓ 取消原因: {reason}")
        print()
        
        return {
            "success": True,
            "message": "预订已取消",
            "booking_id": booking_id,
            "new_status": "cancelled",
            "cancel_reason": reason
        }


class PublicDataOperation:
    """公共数据操作 - 修改餐厅信息"""
    
    @staticmethod
    def execute(restaurant_id: str, owner_id: str, current_user_id: str, 
                updates: Dict[str, Any], evidence: str):
        """
        餐厅所有者修改餐厅信息
        
        策略：
        1. 身份验证 ✓
        2. 所有权检查 ✓
        3. 状态验证 ✓
        4. 记录修改原因 ✓
        5. 提交审核 ✓
        6. 等待管理员批准 ✓
        """
        policy = OPERATION_POLICIES[OperationType.MODIFY_RESTAURANT_INFO]
        
        print(f"【公共数据操作】修改餐厅信息")
        print(f"策略: {policy}")
        print()
        
        # 步骤1：身份验证
        print("  [步骤1] 身份验证")
        if not current_user_id:
            raise PermissionError("未登录")
        print(f"    ✓ 用户已登录: {current_user_id}")
        print()
        
        # 步骤2：所有权检查
        print("  [步骤2] 所有权检查")
        if owner_id != current_user_id:
            raise PermissionError("只有餐厅所有者可以修改信息")
        print(f"    ✓ 餐厅所有者验证通过")
        print()
        
        # 步骤3：状态验证
        print("  [步骤3] 餐厅状态验证")
        restaurant_status = "active"  # 可能的值: active, suspended, closed
        if restaurant_status == "suspended":
            raise ValueError("餐厅已被暂停，无法修改信息")
        if restaurant_status == "closed":
            raise ValueError("餐厅已关闭，无法修改")
        print(f"    ✓ 餐厅状态有效 (当前: {restaurant_status})")
        print()
        
        # 步骤4：创建修改提案（不直接更新）
        print("  [步骤4] 创建修改提案")
        print(f"    ✓ 提案ID: proposal_20260327_001")
        print(f"    ✓ 修改字段: {list(updates.keys())}")
        print(f"    ✓ 修改原因/证明: {evidence}")
        print()
        
        # 步骤5：提交审核
        print("  [步骤5] 提交管理员审核")
        print(f"    ✓ 状态: pending_approval")
        print(f"    ✓ 分配审核员: admin_team")
        print()
        
        # 步骤6：记录审计日志
        print("  [步骤6] 记录审计日志")
        print(f"    ✓ 操作类型: MODIFY_RESTAURANT_INFO")
        print(f"    ✓ 修改原因/证明: {evidence}")
        print()
        
        return {
            "success": True,
            "message": "修改提案已提交审核",
            "proposal_id": "proposal_20260327_001",
            "status": "pending_approval",
            "estimated_review_time": "1-3 个工作日"
        }


# ============================================================================
# 演示
# ============================================================================

def demo():
    print("\n" + "="*80)
    print("📋 区分操作类型和对应的安全策略")
    print("="*80)
    
    # ========================================================================
    # 演示1：私人数据操作
    # ========================================================================
    print("\n\n【演示1】私人数据修改 - 用户修改自己的个人信息")
    print("-"*80)
    
    try:
        result = PrivateDataOperation.execute(
            user_id="user_123",
            current_user_id="user_123",
            updates={
                "phone": "13800138000",
                "address": "新地址"
            }
        )
        print(f"\n✅ 操作成功: {result['message']}")
    except Exception as e:
        print(f"\n❌ 操作失败: {e}")
    
    # ========================================================================
    # 演示2：共享资源操作
    # ========================================================================
    print("\n\n【演示2】共享资源操作 - 取消预订")
    print("-"*80)
    
    try:
        result = SharedResourceOperation.execute(
            booking_id="book_001",
            user_id="user_123",
            current_user_id="user_123",
            reason="工作日期调整，无法准时到达"
        )
        print(f"\n✅ 操作成功: {result['message']}")
    except Exception as e:
        print(f"\n❌ 操作失败: {e}")
    
    # ========================================================================
    # 演示3：公共数据操作
    # ========================================================================
    print("\n\n【演示3】公共数据操作 - 修改餐厅信息")
    print("-"*80)
    
    try:
        result = PublicDataOperation.execute(
            restaurant_id="rest_001",
            owner_id="owner_001",
            current_user_id="owner_001",
            updates={
                "opening_hours": "11:00-23:00",
                "capacity": 150
            },
            evidence="餐厅进行了装修和扩建，座位数增加"
        )
        print(f"\n✅ 操作成功: {result['message']}")
    except Exception as e:
        print(f"\n❌ 操作失败: {e}")
    
    # ========================================================================
    # 总结
    # ========================================================================
    print("\n\n" + "="*80)
    print("🎯 操作类型和安全策略总结")
    print("="*80)
    
    summary = """
┌─────────────────────────────────────────────────────────────────────────────┐
│                          操作类型    安全策略对比                             │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  1️⃣ 私人数据操作 (Private Data)                                             │
│     └─ 修改自己的个人信息                                                    │
│        安全策略: 身份验证 → 所有权检查 ✓ 直接更新                            │
│        特点: 最小干预，用户可完全控制                                        │
│        审计: 记录操作日志                                                    │
│        原因记录: ✗ 不需要                                                    │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  2️⃣ 共享资源操作 (Shared Resource)                                          │
│     └─ 取消预订/释放资源/暂停服务                                             │
│        安全策略: 身份验证 → 所有权检查 → 状态验证 → 标记状态                 │
│        特点: 状态转移，保留历史，不直接删除                                   │
│        审计: 记录操作日志 + 修改原因                                         │
│        原因记录: ✓ 必需（为何取消）                                          │
│        数据库: UPDATE status='cancelled', reason='...'                      │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  3️⃣ 公共数据操作 (Public Data)                                              │
│     └─ 修改餐厅信息/创建促销/发布列表                                        │
│        安全策略: 身份验证 → 所有权检查 → 状态验证 → 创建提案 → 审核流程      │
│        特点: 完整审核流程，管理员最终批准                                     │
│        审计: 完整审计追踪                                                    │
│        原因记录: ✓ 必需（修改原因/证明）                                     │
│        工作流: 提案 → 待审核 → [批准/拒绝] → 应用/驳回                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘

🔑 关键差异：

  数据删除方式:
    • 私人数据: 可以直接删除 DELETE ✓
    • 共享资源: 标记状态 UPDATE status='cancelled' (保留记录)
    • 公共数据: 工作流处理 (待审核 → 批准 → 应用)

  原因记录:
    • 私人数据: 不需要原因 (用户的自由)
    • 共享资源: 必需原因 (对系统的影响)
    • 公共数据: 必需原因+证明 (需要审核员评估)

  审核流程:
    • 私人数据: 无 (本人操作即可)
    • 共享资源: 无 (本人确认即可)
    • 公共数据: 有 (管理员最终批准)

🛡️ 安全原则：

  1. 最小权限原则:
     ✓ 用户只能修改自己的私人数据
     ✓ 用户只能取消自己的预订
     ✓ 餐厅主只能修改自己的餐厅

  2. 审计追踪:
     ✓ 所有操作记录用户、时间、原因
     ✓ 无法完全删除历史
     ✓ 支持操作回溯

  3. 数据完整性:
     ✓ 共享资源通过标记状态保留历史
     ✓ 公共数据通过审评流程确保质量
     ✓ 私人数据通过所有权检查保护隐私
"""
    print(summary)


if __name__ == "__main__":
    demo()
