#!/usr/bin/env python3
"""直接测试参数提取逻辑"""
import re
from datetime import datetime, timedelta

def test_extract_params(text: str, tool_name: str):
    """测试参数提取"""
    print(f"\n测试输入: '{text}'")
    print(f"工具名: {tool_name}")
    print("-" * 50)
    
    params = {}

    # 餐厅名称提取
    restaurant_keywords = ["金牌川菜馆", "川菜", "餐厅", "饭店"]
    for keyword in restaurant_keywords:
        if keyword in text:
            params["restaurant_name"] = "金牌川菜馆"
            print(f"✓ 找到餐厅: {keyword} -> 金牌川菜馆")
            break

    # 日期提取
    if "明天" in text:
        tomorrow = datetime.now() + timedelta(days=1)
        params["date"] = tomorrow.strftime("%Y-%m-%d")
        print(f"✓ 找到日期: 明天 -> {params['date']}")
    elif "今天" in text:
        today = datetime.now()
        params["date"] = today.strftime("%Y-%m-%d")
        print(f"✓ 找到日期: 今天 -> {params['date']}")

    # 时间提取（支持 "19点" 和 "19:00" 两种格式）
    time_match = re.search(r'(\d{1,2})[:：点](\d{2})?', text)
    if time_match:
        hour = time_match.group(1)
        minute = time_match.group(2) or "00"
        params["time"] = f"{int(hour):02d}:{minute}"
        print(f"✓ 找到时间: {time_match.group(0)} -> {params['time']}")
    else:
        print(f"✗ 未找到时间 (查找模式: \\d{{1,2}}[:：点]\\d{{2}}?)")

    # 人数提取
    people_match = re.search(r'(\d+)人', text)
    if people_match:
        params["people_count"] = int(people_match.group(1))
        print(f"✓ 找到人数: {people_match.group(0)} -> {params['people_count']}")
    else:
        print(f"✗ 未找到人数 (查找模式: \\d+人)")

    # 姓名提取
    name_match = re.search(r'我叫([^\s，,。\.]+)', text)
    if name_match:
        params["customer_name"] = name_match.group(1)
        print(f"✓ 找到姓名: {name_match.group(0)} -> {params['customer_name']}")
    else:
        print(f"✗ 未找到姓名 (查找模式: 我叫...)")

    # 电话提取
    phone_match = re.search(r'(\d{11})', text)
    if phone_match:
        params["phone"] = phone_match.group(1)
        print(f"✓ 找到电话: {phone_match.group(0)} -> {params['phone']}")
    else:
        print(f"✗ 未找到电话 (查找模式: \\d{{11}})")

    # 地点提取
    location_keywords = ["中关村", "北京", "上海", "深圳"]
    for location in location_keywords:
        if location in text:
            params["location"] = location
            print(f"✓ 找到地点: {location}")
            break

    # 菜系提取
    cuisine_keywords = ["川菜", "粤菜", "湘菜", "火锅", "海鲜"]
    for cuisine in cuisine_keywords:
        if cuisine in text:
            params["cuisine_type"] = cuisine
            print(f"✓ 找到菜系: {cuisine}")
            break

    print(f"\n最终参数: {params}")
    return params


# 测试用例
test_cases = [
    ("我想在中关村找一家四川菜餐厅", "search_restaurants"),
    ("查一下金牌川菜馆今天的可用时间", "check_availability"),
    ("帮我预订金牌川菜馆，明天19点，4人，我叫张三，电话13800138000", "make_booking"),
]

print("\n" + "="*60)
print("参数提取测试")
print("="*60)

for text, tool in test_cases:
    test_extract_params(text, tool)

print("\n" + "="*60)
print("✓ 测试完成")
print("="*60)
