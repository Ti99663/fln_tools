"""
高级抽象架构的基础框架实现

这个文件包含：
1. Tool 系统
2. Intent 系统
3. Workflow 生成系统
4. LangGraph 集成
"""

from typing import Dict, List, Any, Optional, TypedDict, Callable
from dataclasses import dataclass, field
from enum import Enum
import json
from datetime import datetime
from abc import ABC, abstractmethod

# ============================================================================
# Part 1: 工具系统 (Tool System)
# ============================================================================

class ToolCategory(Enum):
    """工具分类"""
    QUERY = "query"              # 查询类
    ACTION = "action"            # 动作类
    NOTIFICATION = "notification"  # 通知类
    PAYMENT = "payment"          # 支付类
    AUTH = "auth"               # 认证类
    OTHER = "other"

@dataclass
class ToolMetadata:
    """工具的元数据"""
    name: str
    description: str
    category: ToolCategory
    
    # 输入输出
    input_schema: Dict[str, str] = field(default_factory=dict)
    output_schema: Dict[str, str] = field(default_factory=dict)
    
    # 依赖关系
    preconditions: List[str] = field(default_factory=list)      # 前置条件（依赖的其他工具）
    side_effects: List[str] = field(default_factory=list)       # 副作用（会触发的其他工具）
    
    # 可选信息
    is_optional: bool = False     # 是否可选
    is_async: bool = False        # 是否异步
    timeout: int = 30             # 超时时间(秒)
    retry_count: int = 1          # 重试次数
    
    # 数据映射
    input_mapping: Dict[str, str] = field(default_factory=dict)  # 输入参数映射
    output_mapping: Dict[str, str] = field(default_factory=dict) # 输出参数映射

class Tool(ABC):
    """工具基类"""
    
    def __init__(self, metadata: ToolMetadata):
        self.metadata = metadata
    
    @abstractmethod
    def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行工具
        
        Args:
            inputs: 输入参数字典
            
        Returns:
            输出结果字典
        """
        pass
    
    def get_dependencies(self) -> List[str]:
        """获取依赖的工具"""
        return self.metadata.preconditions
    
    def get_side_effects(self) -> List[str]:
        """获取会触发的工具"""
        return self.metadata.side_effects


class ToolRegistry:
    """工具注册表"""
    
    def __init__(self):
        self._tools: Dict[str, Tool] = {}
        self._metadata: Dict[str, ToolMetadata] = {}
    
    def register(self, tool: Tool) -> None:
        """注册一个工具"""
        name = tool.metadata.name
        self._tools[name] = tool
        self._metadata[name] = tool.metadata
        print(f"✓ 工具已注册: {name}")
    
    def get_tool(self, name: str) -> Optional[Tool]:
        """获取工具"""
        return self._tools.get(name)
    
    def get_metadata(self, name: str) -> Optional[ToolMetadata]:
        """获取工具的元数据"""
        return self._metadata.get(name)
    
    def find_tools_for_output(self, output_name: str) -> List[str]:
        """找到能产生某个输出的所有工具"""
        result = []
        for name, metadata in self._metadata.items():
            if output_name in metadata.output_schema:
                result.append(name)
        # 也检查直接依赖的工具名称
        if not result:
            for name in self._tools.keys():
                if output_name == name or output_name.startswith(name + "."):
                    result.append(name)
        return result
    
    def find_tools_for_action(self, action: str) -> List[str]:
        """根据动作名称找工具"""
        result = []
        for name, metadata in self._metadata.items():
            if action.lower() in metadata.description.lower():
                result.append(name)
        return result
    
    def list_tools(self) -> List[str]:
        """列出所有工具"""
        return list(self._tools.keys())
    
    def get_dependency_graph(self) -> Dict[str, List[str]]:
        """获取工具的依赖图"""
        graph = {}
        for name, metadata in self._metadata.items():
            graph[name] = metadata.preconditions
        return graph


# ============================================================================
# Part 2: 意图系统 (Intent System)
# ============================================================================

@dataclass
class Intent:
    """用户意图基类"""
    name: str
    description: str
    primary_tools: List[str] = field(default_factory=list)  # 主要工具
    required_outputs: List[str] = field(default_factory=list)
    optional_outputs: List[str] = field(default_factory=list)
    
    def get_all_outputs(self) -> List[str]:
        """获取所有需要的输出"""
        return self.required_outputs + self.optional_outputs


# 具体意图示例
class CancelBookingIntent(Intent):
    """取消预定意图"""
    def __init__(self):
        super().__init__(
            name="cancel_booking",
            description="用户想要取消已有的预定",
            primary_tools=["cancel_booking"],  # 核心工具
            required_outputs=["booking_id"],
            optional_outputs=["reason"]
        )


class ModifyBookingIntent(Intent):
    """修改预定意图"""
    def __init__(self):
        super().__init__(
            name="modify_booking",
            description="用户想要修改已有的预定",
            primary_tools=["modify_booking"],
            required_outputs=["booking_id", "new_time"],
            optional_outputs=["party_size", "reason"]
        )


class SearchAndBuyIntent(Intent):
    """搜索并购买意图"""
    def __init__(self):
        super().__init__(
            name="search_and_buy",
            description="用户想要搜索商品并进行购买",
            primary_tools=["search_products", "make_payment"],
            required_outputs=["product_id", "quantity", "address"],
            optional_outputs=["coupon_code", "gift_message"]
        )


class IntentRegistry:
    """意图注册表"""
    
    def __init__(self):
        self._intents: Dict[str, type] = {}
    
    def register(self, intent_class: type) -> None:
        """注册一个意图类"""
        # 创建实例来获取名称
        instance = intent_class()
        self._intents[instance.name] = intent_class
    
    def get_intent_class(self, name: str) -> Optional[type]:
        """获取意图类"""
        return self._intents.get(name)
    
    def create_intent(self, name: str) -> Optional[Intent]:
        """创建意图实例"""
        intent_class = self._intents.get(name)
        if intent_class:
            return intent_class()
        return None


# ============================================================================
# Part 3: 工作流系统 (Workflow System)
# ============================================================================

@dataclass
class WorkflowNode:
    """工作流节点"""
    tool_name: str
    dependencies: List[str] = field(default_factory=list)
    
    def __hash__(self):
        return hash(self.tool_name)


class Workflow:
    """工作流图"""
    
    def __init__(self):
        self.nodes: Dict[str, WorkflowNode] = {}
        self.edges: Dict[str, List[str]] = {}  # 有向边
    
    def add_node(self, tool_name: str, dependencies: List[str] = None) -> None:
        """添加节点"""
        dependencies = dependencies or []
        node = WorkflowNode(tool_name, dependencies)
        self.nodes[tool_name] = node
        self.edges[tool_name] = []
        
        # 添加边
        for dep in dependencies:
            if dep not in self.edges:
                self.edges[dep] = []
            if tool_name not in self.edges[dep]:
                self.edges[dep].append(tool_name)
    
    def get_executable_nodes(self, completed: set) -> List[str]:
        """获取当前可以执行的节点"""
        executable = []
        for node_name, node in self.nodes.items():
            if node_name in completed:
                continue
            # 检查所有依赖是否完成
            if all(dep in completed for dep in node.dependencies):
                executable.append(node_name)
        return executable
    
    def topological_sort(self) -> List[str]:
        """拓扑排序"""
        # Kahn 算法
        in_degree = {node: len(self.nodes[node].dependencies) for node in self.nodes}
        queue = [node for node in self.nodes if in_degree[node] == 0]
        result = []
        
        while queue:
            node = queue.pop(0)
            result.append(node)
            
            for neighbor in self.edges.get(node, []):
                in_degree[neighbor] -= 1
                if in_degree[neighbor] == 0:
                    queue.append(neighbor)
        
        return result
    
    def visualize(self) -> str:
        """可视化工作流"""
        lines = ["📋 工作流:"]
        sorted_nodes = self.topological_sort()
        
        for i, node in enumerate(sorted_nodes):
            node_obj = self.nodes[node]
            indent = "  " if i > 0 else ""
            deps = f" (依赖: {', '.join(node_obj.dependencies)})" if node_obj.dependencies else ""
            lines.append(f"{indent}[{i+1}] {node}{deps}")
        
        return "\n".join(lines)


class WorkflowGenerator:
    """工作流生成器"""
    
    def __init__(self, tool_registry: ToolRegistry):
        self.tool_registry = tool_registry
    
    def generate(self, intent: Intent) -> Workflow:
        """根据意图生成工作流
        
        核心算法：
        1. 如果意图定义了 primary_tools，从这些工具开始
        2. 否则，从 intent 的 required_outputs 开始
        3. 递归处理工具的 preconditions（前置工具）
        4. 生成最终的工作流图
        """
        workflow = Workflow()
        visited = set()
        
        # 第一步：收集所有需要的工具
        def collect_tools(tool_or_output: str):
            """递归收集所有工具及其依赖"""
            if tool_or_output in visited:
                return
            
            # 首先尝试作为工具名
            if tool_or_output in self.tool_registry.list_tools():
                visited.add(tool_or_output)
                metadata = self.tool_registry.get_metadata(tool_or_output)
                # 递归处理这个工具的前置条件
                for prereq in metadata.preconditions:
                    collect_tools(prereq)
                return
            
            # 尝试作为输出名
            tools_for_output = self.tool_registry.find_tools_for_output(tool_or_output)
            if tools_for_output:
                for tool in tools_for_output:
                    collect_tools(tool)
                return
        
        # 第二步：如果意图有 primary_tools，优先收集
        if hasattr(intent, 'primary_tools') and intent.primary_tools:
            for tool in intent.primary_tools:
                collect_tools(tool)
        else:
            # 否则从需要的输出开始
            for output in intent.required_outputs:
                collect_tools(output)
        
        # 第三步：构建工作流图
        for tool_name in visited:
            metadata = self.tool_registry.get_metadata(tool_name)
            workflow.add_node(tool_name, metadata.preconditions)
        
        return workflow


# ============================================================================
# Part 4: LangGraph State 和节点
# ============================================================================

class AgentState(TypedDict):
    """Agent的全局状态"""
    user_input: str
    intent: Optional[Intent]
    workflow: Optional[Workflow]
    outputs: Dict[str, Any]      # 各工具的执行结果
    completed_steps: List[str]   # 已完成的步骤
    errors: Dict[str, str]       # 每个步骤的错误信息
    messages: List[Dict]         # 消息历史


# LangGraph 节点函数
def recognize_intent_node(
    state: AgentState,
    llm_client,
    intent_registry: IntentRegistry
) -> AgentState:
    """节点1：识别用户意图"""
    # 这里应该调用LLM来识别意图
    # 为了演示，这里简化了
    
    user_input = state["user_input"]
    
    # 简单的关键词检测（实际应该用LLM）
    if "取消" in user_input and "预定" in user_input:
        state["intent"] = CancelBookingIntent()
    elif "修改" in user_input:
        state["intent"] = ModifyBookingIntent()
    elif "搜索" in user_input and "购买" in user_input:
        state["intent"] = SearchAndBuyIntent()
    
    return state


def generate_workflow_node(
    state: AgentState,
    workflow_generator: WorkflowGenerator
) -> AgentState:
    """节点2：根据意图生成工作流"""
    if not state["intent"]:
        return state
    
    state["workflow"] = workflow_generator.generate(state["intent"])
    return state


def execute_workflow_step_node(
    state: AgentState,
    tool_registry: ToolRegistry
) -> AgentState:
    """节点3：执行工作流的下一步"""
    if not state["workflow"]:
        return state
    
    workflow = state["workflow"]
    completed = set(state["completed_steps"])
    
    # 获取可以执行的节点
    executable_nodes = workflow.get_executable_nodes(completed)
    
    # 执行每个可执行的节点
    for node_name in executable_nodes:
        tool = tool_registry.get_tool(node_name)
        if not tool:
            state["errors"][node_name] = f"工具 '{node_name}' 未找到"
            continue
        
        try:
            # 收集输入参数（从之前的输出中）
            metadata = tool_registry.get_metadata(node_name)
            inputs = {}
            
            for input_param, output_source in metadata.input_mapping.items():
                if output_source in state["outputs"]:
                    inputs[input_param] = state["outputs"][output_source]
            
            # 执行工具
            result = tool.execute(inputs)
            state["outputs"][node_name] = result
            state["completed_steps"].append(node_name)
            
        except Exception as e:
            state["errors"][node_name] = str(e)
    
    return state


def should_continue(state: AgentState) -> str:
    """条件判断：是否还有步骤需要执行"""
    if not state["workflow"]:
        return "end"
    
    workflow = state["workflow"]
    completed = set(state["completed_steps"])
    executable = workflow.get_executable_nodes(completed)
    
    if executable:
        return "execute"  # 继续执行
    else:
        return "end"      # 完成


# ============================================================================
# Demo: 如何使用这个框架
# ============================================================================

def demo():
    """演示高级抽象框架的使用"""
    
    print("\n" + "="*70)
    print("🚀 高级抽象框架演示")
    print("="*70)
    
    # 步骤1：创建工具注册表
    tool_registry = ToolRegistry()
    
    # 步骤2：注册工具（注意：这里只是注册元数据，实际工具实现略）
    # 为了演示，我们创建简单的模拟工具
    
    class MockTool(Tool):
        def execute(self, inputs: Dict[str, Any]) -> Dict[str, Any]:
            return {"success": True, "data": f"执行 {self.metadata.name} 完成"}
    
    # 注册工具链
    tools_config = [
        ToolMetadata(
            name="get_booking_history",
            description="查询用户的所有预定记录",
            category=ToolCategory.QUERY,
            output_schema={"booking_id": "str", "bookings": "List[Booking]"},
            preconditions=[],
        ),
        ToolMetadata(
            name="cancel_booking",
            description="取消一个具体的预定",
            category=ToolCategory.ACTION,
            input_schema={"booking_id": "str"},
            output_schema={"success": "bool"},
            preconditions=["get_booking_history"],
            input_mapping={"booking_id": "get_booking_history.booking_id"},
        ),
        ToolMetadata(
            name="send_sms",
            description="发送短信给用户",
            category=ToolCategory.NOTIFICATION,
            input_schema={"message": "str"},
            output_schema={"message_id": "str"},
            preconditions=["cancel_booking"],
            is_optional=True,
        ),
    ]
    
    for config in tools_config:
        tool = MockTool(config)
        tool_registry.register(tool)
    
    # 步骤3：创建工作流生成器
    workflow_gen = WorkflowGenerator(tool_registry)
    
    # 步骤4：创建意图并生成工作流
    print("\n📝 场景：用户想要取消预定")
    print("-" * 70)
    
    intent = CancelBookingIntent()
    print(f"✓ 识别意图: {intent.name}")
    print(f"  描述: {intent.description}")
    print(f"  需要输出: {intent.required_outputs}")
    
    workflow = workflow_gen.generate(intent)
    print(f"\n✓ 生成工作流")
    print(workflow.visualize())
    
    # 步骤5：展示工作流的执行顺序
    print("\n✓ 执行顺序:")
    sorted_nodes = workflow.topological_sort()
    for i, node in enumerate(sorted_nodes, 1):
        node_meta = tool_registry.get_metadata(node)
        deps = f" ← {node_meta.preconditions}" if node_meta.preconditions else ""
        print(f"  {i}. 执行 {node}{deps}")
    
    # 步骤6：对比传统方式
    print("\n" + "-"*70)
    print("📊 对比")
    print("-"*70)
    print("传统方式:")
    print("  ❌ Agent 代码中硬编码: if取消 → 查询 → 取消 → 发短信")
    print("  ❌ 每次新增功能都要修改agent代码")
    print("")
    print("高级抽象方式:")
    print("  ✅ Agent 代码不变")
    print("  ✅ 只需注册工具和定义意图")
    print("  ✅ 工作流自动生成")
    print("  ✅ 新功能添加成本线性 O(n)")


if __name__ == "__main__":
    demo()
