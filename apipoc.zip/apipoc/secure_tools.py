"""
安全的、可复用的工具系统实现

展示如何在实际项目中使用权限控制和数据源抽象
"""

from enum import Enum
from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field
from abc import ABC, abstractmethod
from datetime import datetime
import json

# ============================================================================
# Part 1: 权限和用户系统
# ============================================================================

class ActionType(Enum):
    """工具的动作类型"""
    READ = "read"
    CREATE = "create"
    UPDATE = "update"
    DELETE = "delete"

class PermissionLevel(Enum):
    """权限级别"""
    ADMIN = 100
    MODERATOR = 50
    USER = 10
    GUEST = 0

class DataOwnershipType(Enum):
    """数据所有权类型 - 决定了操作的执行流程"""
    PRIVATE = "private"    # 私人数据：用户自己的信息（最小验证）
    SHARED = "shared"      # 共享资源：涉及其他方的资源（中等验证+状态转移）
    PUBLIC = "public"      # 公共数据：公共信息（完整验证+工作流）

@dataclass
class User:
    """用户信息"""
    id: str
    name: str
    role: str
    permission_level: PermissionLevel
    
    def __repr__(self):
        return f"User({self.id}, {self.name}, {self.role})"


class ToolContext:
    """工具执行的上下文（包含权限、审计等信息）"""
    
    def __init__(self, user: User, data_source_config: Dict[str, Any] = None):
        self.user = user
        self.data_source_config = data_source_config or {}
        self.audit_log: List[Dict] = []
        self.request_id = self._generate_request_id()
    
    def _generate_request_id(self) -> str:
        """生成请求ID用于追踪"""
        import uuid
        return f"req_{uuid.uuid4().hex[:8]}"
    
    def log_action(self, action: ActionType, resource: str, status: str, details: Dict = None):
        """记录操作日志"""
        self.audit_log.append({
            "timestamp": datetime.now().isoformat(),
            "request_id": self.request_id,
            "user_id": self.user.id,
            "user_name": self.user.name,
            "action": action.value,
            "resource": resource,
            "status": status,
            "details": details or {}
        })
    
    def has_permission(self, permission_level: PermissionLevel) -> bool:
        """检查权限"""
        return self.user.permission_level.value >= permission_level.value
    
    def print_audit_log(self):
        """打印审计日志"""
        print("\n📋 审计日志:")
        print("-" * 80)
        for log in self.audit_log:
            action_icon = "✓" if log["status"] == "success" else ("✗" if log["status"] == "error" else "⊘")
            print(f"[{log['timestamp']}] {action_icon} {log['user_name']:10} | "
                  f"{log['action']:6} {log['resource']:20} | {log['status']}")
            if log.get("details"):
                for key, value in log["details"].items():
                    if key != "reason":
                        print(f"         └─ {key}: {value}")


# ============================================================================
# Part 2: 数据源抽象
# ============================================================================

class DataSource(ABC):
    """数据源抽象接口"""
    
    @abstractmethod
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        """执行查询"""
        pass
    
    @abstractmethod
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """插入数据"""
        pass
    
    @abstractmethod
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        """更新数据"""
        pass
    
    @abstractmethod
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        """删除数据"""
        pass


class MockMySQLDataSource(DataSource):
    """模拟MySQL数据源（用于演示）"""
    
    def __init__(self, host: str, user: str, password: str, database: str):
        self.host = host
        self.database = database
        # 模拟数据库数据
        self.tables = {
            "bookings": [
                {
                    "id": "book_001",
                    "user_id": "user_123",
                    "restaurant": "金牌川菜馆",
                    "date": "2026-03-28",
                    "time": "19:00",
                    "people": 4,
                    "status": "confirmed"
                },
                {
                    "id": "book_002",
                    "user_id": "user_123",
                    "restaurant": "精品粤菜",
                    "date": "2026-03-29",
                    "time": "18:30",
                    "people": 2,
                    "status": "confirmed"
                },
                {
                    "id": "book_003",
                    "user_id": "user_456",
                    "restaurant": "日本寿司店",
                    "date": "2026-03-30",
                    "time": "20:00",
                    "people": 3,
                    "status": "confirmed"
                }
            ]
        }
    
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        """执行查询"""
        # 这是简化的实现，实际应该用ORM或SQL解析
        print(f"  [MySQL] 执行查询: {sql[:50]}...")
        
        # 简单的过滤逻辑
        if "user_id" in sql:
            user_id = params[0] if params else None
            return [b for b in self.tables["bookings"] if b["user_id"] == user_id]
        
        return self.tables["bookings"]
    
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """插入数据"""
        print(f"  [MySQL] 插入 {table}: {data}")
        self.tables[table].append(data)
        return 1
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        """更新数据"""
        print(f"  [MySQL] 更新 {table}: set {data} where {where}")
        
        table_data = self.tables.get(table, [])
        count = 0
        for row in table_data:
            if all(row.get(k) == v for k, v in where.items()):
                row.update(data)
                count += 1
        
        return count
    
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        """删除数据"""
        print(f"  [MySQL] 删除 {table} where {where}")
        
        table_data = self.tables.get(table, [])
        before_count = len(table_data)
        
        self.tables[table] = [
            row for row in table_data
            if not all(row.get(k) == v for k, v in where.items())
        ]
        
        return before_count - len(self.tables[table])


class MockPostgreSQLDataSource(DataSource):
    """模拟PostgreSQL数据源"""
    
    def __init__(self, host: str, user: str, password: str, database: str):
        self.host = host
        self.database = database
        print(f"  [PostgreSQL] 连接到 {database} @{host}")
    
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        print(f"  [PostgreSQL] 查询: {sql[:50]}...")
        return []
    
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        print(f"  [PostgreSQL] 插入 {table}")
        return 1
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        print(f"  [PostgreSQL] 更新 {table}")
        return 1
    
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        print(f"  [PostgreSQL] 删除 {table}")
        return 1


# ============================================================================
# Part 3: 通用工具基类
# ============================================================================

class SecureTool(ABC):
    """安全的、可复用的工具基类
    
    根据data_ownership类型自动选择执行流程：
    - PRIVATE: 私人数据操作（最小验证）
    - SHARED: 共享资源操作（中等验证+通知）
    - PUBLIC: 公共数据操作（完整验证+工作流）
    """
    
    def __init__(self, name: str, action_type: ActionType, required_permission: PermissionLevel,
                 data_ownership: DataOwnershipType = None):
        self.name = name
        self.action_type = action_type
        self.required_permission = required_permission
        self.data_ownership = data_ownership or DataOwnershipType.PRIVATE  # 默认私人数据
    
    def execute(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行工具的入口方法
        
        根据data_ownership类型自动路由到对应的流程
        """
        try:
            # 步骤1：通用权限检查
            if not self._check_permission(context):
                context.log_action(
                    self.action_type,
                    self.name,
                    "denied",
                    {"reason": "insufficient_permission"}
                )
                raise PermissionError(
                    f"用户 {context.user.name} ({context.user.role}) 没有权限执行 {self.name}"
                )
            
            # 步骤2：输入验证
            self._validate_inputs(inputs)
            
            # 步骤3：根据操作类型路由到对应流程 (新增)
            if self.data_ownership == DataOwnershipType.PRIVATE:
                result = self._execute_private_flow(context, inputs)
            elif self.data_ownership == DataOwnershipType.SHARED:
                result = self._execute_shared_flow(context, inputs)
            elif self.data_ownership == DataOwnershipType.PUBLIC:
                result = self._execute_public_flow(context, inputs)
            else:
                # 回退到原有逻辑
                self._check_preconditions(context, inputs)
                result = self._execute_impl(context, inputs)
            
            # 步骤4：记录成功
            context.log_action(
                self.action_type,
                self.name,
                "success",
                {"flow_type": self.data_ownership.value, "input_keys": list(inputs.keys())}
            )
            
            return result
        
        except PermissionError as e:
            context.log_action(self.action_type, self.name, "error", {"error": str(e)})
            raise
        except ValueError as e:
            context.log_action(self.action_type, self.name, "error", {"error": str(e)})
            raise
        except Exception as e:
            context.log_action(self.action_type, self.name, "error", {"error": str(e)})
            raise
    
    def _check_permission(self, context: ToolContext) -> bool:
        """检查权限"""
        has_perm = context.has_permission(self.required_permission)
        if has_perm:
            print(f"  ✓ 权限检查通过 ({context.user.name}: {context.user.permission_level.name})")
        else:
            print(f"  ✗ 权限不足 ({context.user.name} 需要 {self.required_permission.name})")
        return has_perm
    
    def _validate_inputs(self, inputs: Dict[str, Any]) -> None:
        """验证输入参数"""
        pass  # 子类可以覆盖
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """检查前置条件"""
        pass  # 子类可以覆盖
    
    # ========== 新增：三种操作流程 =========
    
    def _execute_private_flow(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """私人数据操作流程（最小验证）
        
        流程：所有权检查 → 执行操作 → 审计日志
        """
        print(f"  [私人数据流程] 开始执行...")
        # 所有权检查
        self._check_preconditions(context, inputs)
        print(f"  ✓ 前置条件检查通过")
        
        # 执行业务逻辑
        result = self._execute_impl(context, inputs)
        print(f"  ✓ 操作执行成功")
        
        return result
    
    def _execute_shared_flow(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """共享资源操作流程（中等验证+状态转移+通知）
        
        流程：所有权检查 → 状态验证 → 原因收集 → 执行操作 → 通知利益方 → 审计日志
        """
        print(f"  [共享资源流程] 开始执行...")
        
        # 所有权和状态检查
        self._check_preconditions(context, inputs)
        print(f"  ✓ 所有权和状态检查通过")
        
        # 强制要求原因（对于共享资源操作）
        if 'reason' not in inputs:
            raise ValueError("共享资源操作必须提供取消/变更原因 (reason 字段)")
        print(f"  ✓ 原因已提供: {inputs['reason']}")
        
        # 执行业务逻辑
        result = self._execute_impl(context, inputs)
        print(f"  ✓ 状态已转移")
        
        # 通知利益方（模拟）
        self._notify_stakeholders(context, inputs, result)
        print(f"  ✓ 已通知相关方")
        
        return result
    
    def _execute_public_flow(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """公共数据操作流程（完整验证+工作流）
        
        流程：所有权检查 → 状态验证 → 证明收集 → 创建提案 → 提交审核 → 审计日志
        """
        print(f"  [公共数据流程] 开始执行...")
        
        # 所有权和状态检查
        self._check_preconditions(context, inputs)
        print(f"  ✓ 所有权和状态检查通过")
        
        # 强制要求证明
        if 'evidence' not in inputs:
            raise ValueError("公共数据操作必须提供修改证明 (evidence 字段)")
        print(f"  ✓ 修改证明已提供")
        
        # 创建提案（不直接执行）
        proposal = self._create_proposal(context, inputs)
        print(f"  ✓ 提案已创建: {proposal.get('proposal_id')}")
        
        # 提交审核（异步）
        self._submit_for_approval(context, proposal)
        print(f"  ✓ 已提交管理员审核")
        
        return {
            "success": True,
            "proposal_id": proposal.get("proposal_id"),
            "status": "pending_approval",
            "message": "提案已提交审核，请等待管理员审批"
        }
    
    def _notify_stakeholders(self, context: ToolContext, inputs: Dict[str, Any], result: Dict[str, Any]) -> None:
        """通知利益方（共享资源操作）"""
        # 模拟通知机制
        print(f"    → [通知] 已发送消息给相关方")
    
    def _create_proposal(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """创建提案（公共数据操作）"""
        import uuid
        proposal_id = f"prop_{datetime.now().strftime('%Y%m%d%H%M%S')}_{uuid.uuid4().hex[:4]}"
        return {
            "proposal_id": proposal_id,
            "creator": context.user.id,
            "inputs": inputs,
            "timestamp": datetime.now().isoformat(),
            "status": "pending_approval"
        }
    
    def _submit_for_approval(self, context: ToolContext, proposal: Dict[str, Any]) -> None:
        """提交审核（公共数据操作）"""
        # 模拟提交审核
        print(f"    → [审核] 已提交给管理员队伍审批")
    
    @abstractmethod
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """实际执行的业务逻辑"""
        pass
    
    def _get_data_source(self, context: ToolContext) -> DataSource:
        """根据配置获取数据源"""
        config = context.data_source_config
        source_type = config.get("type", "mysql")
        
        if source_type == "mysql":
            return MockMySQLDataSource(
                host=config.get("host", "localhost"),
                user=config.get("user", "root"),
                password=config.get("password", ""),
                database=config.get("database", "restaurant_db")
            )
        elif source_type == "postgresql":
            return MockPostgreSQLDataSource(
                host=config.get("host", "localhost"),
                user=config.get("user", "postgres"),
                password=config.get("password", ""),
                database=config.get("database", "restaurant_db")
            )
        else:
            raise ValueError(f"不支持的数据源: {source_type}")


# ============================================================================
# Part 4: 具体工具实现
# ============================================================================

class GetUserBookingsTool(SecureTool):
    """查询用户预订的工具（可复用）"""
    
    def __init__(self):
        super().__init__(
            name="get_user_bookings",
            action_type=ActionType.READ,
            required_permission=PermissionLevel.USER,
            data_ownership=DataOwnershipType.PRIVATE  # READ操作是私人的：要么查看自己，要么有权限查看他人
        )
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """前置条件：用户只能查询自己的数据"""
        user_id = inputs.get("user_id")
        
        # 普通用户只能查询自己的数据
        if context.user.permission_level == PermissionLevel.USER:
            if user_id != context.user.id:
                raise PermissionError(
                    f"用户 {context.user.name} 只能查询自己的数据"
                )
        
        print(f"  ✓ 前置条件检查通过 (查询用户 {user_id})")
    
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行查询"""
        user_id = inputs["user_id"]
        data_source = self._get_data_source(context)
        
        bookings = data_source.query(
            "SELECT * FROM bookings WHERE user_id = ?",
            [user_id]
        )
        
        return {
            "success": True,
            "user_id": user_id,
            "bookings": bookings,
            "count": len(bookings)
        }


class CancelBookingTool(SecureTool):
    """取消预订的工具（可复用）
    
    操作特点：标记状态为cancelled（不删除），记录原因，通知餐厅
    """
    
    def __init__(self):
        super().__init__(
            name="cancel_booking",
            action_type=ActionType.UPDATE,  # 改为UPDATE（因为是标记状态，不是删除）
            required_permission=PermissionLevel.USER,  # 改为USER（用户可取消自己的预订）
            data_ownership=DataOwnershipType.SHARED  # 共享资源：影响餐厅，需要原因记录和通知
        )
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """前置条件检查"""
        booking_id = inputs["booking_id"]
        user_id = inputs.get("user_id")
        
        data_source = self._get_data_source(context)
        
        # 检查预订是否存在
        bookings = data_source.query(
            "SELECT * FROM bookings WHERE id = ?",
            [booking_id]
        )
        
        if not bookings:
            raise ValueError(f"预订 {booking_id} 不存在")
        
        booking = bookings[0]
        
        # 检查权限
        if context.user.permission_level == PermissionLevel.USER:
            # 普通用户只能取消自己的预订
            if booking["user_id"] != context.user.id:
                raise PermissionError(
                    f"用户只能取消自己的预订"
                )
        
        # 检查预订状态
        if booking["status"] == "completed":
            raise ValueError("无法取消已完成的预订")
        
        if booking["status"] == "cancelled":
            raise ValueError("预订已被取消")
        
        print(f"  ✓ 前置条件检查通过 (预订存在且可取消)")
    
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行取消 - 标记状态并记录原因"""
        booking_id = inputs["booking_id"]
        reason = inputs.get("reason", "未提供原因")  # 在shared_flow中已经验证
        data_source = self._get_data_source(context)
        
        affected = data_source.update(
            "bookings",
            {
                "status": "cancelled",
                "cancel_reason": reason,  # 新增：记录取消原因
                "cancelled_at": datetime.now().isoformat()
            },
            {"id": booking_id}
        )
        
        return {
            "success": affected > 0,
            "booking_id": booking_id,
            "affected_rows": affected,
            "reason_recorded": reason  # 新增：确认原因已记录
        }


class UpdateUserInfoTool(SecureTool):
    """更新用户信息的工具（私人数据）
    
    操作特点：用户修改自己的账户信息，只需身份验证
    """
    
    def __init__(self):
        super().__init__(
            name="update_user_info",
            action_type=ActionType.UPDATE,
            required_permission=PermissionLevel.USER,
            data_ownership=DataOwnershipType.PRIVATE  # 私人数据：最小验证
        )
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """前置条件：用户只能修改自己的信息"""
        user_id = inputs.get("user_id")
        
        # 普通用户只能修改自己的数据
        if context.user.permission_level == PermissionLevel.USER:
            if user_id != context.user.id:
                raise PermissionError(
                    f"用户 {context.user.name} 只能修改自己的信息"
                )
        
        print(f"  ✓ 前置条件检查通过 (修改用户 {user_id} 的信息)")
    
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行用户信息更新"""
        user_id = inputs["user_id"]
        update_fields = inputs.get("fields", {})
        
        data_source = self._get_data_source(context)
        
        # 构建用户表（简化演示）
        affected = data_source.update(
            "users",
            update_fields,
            {"id": user_id}
        )
        
        return {
            "success": affected > 0,
            "user_id": user_id,
            "updated_fields": list(update_fields.keys()),
            "affected_rows": affected
        }


# ============================================================================
# Demo
# ============================================================================

def demo():
    """演示安全的工具系统"""
    
    print("\n" + "="*80)
    print("🔐 安全的、可复用的工具系统演示")
    print("="*80)
    
    # 场景1：普通用户查询自己的预订
    print("\n\n【场景1】普通用户查询自己的预订")
    print("-"*80)
    
    user1 = User(
        id="user_123",
        name="张三",
        role="customer",
        permission_level=PermissionLevel.USER
    )
    
    context1 = ToolContext(
        user=user1,
        data_source_config={
            "type": "mysql",
            "host": "localhost",
            "user": "root",
            "password": "password",
            "database": "restaurant_db"
        }
    )
    
    tool_get = GetUserBookingsTool()
    
    try:
        result = tool_get.execute(context1, {
            "user_id": "user_123"
        })
        print(f"\n✓ 查询成功")
        print(f"  - 预订数量: {result['count']}")
        for booking in result['bookings']:
            print(f"    • {booking['restaurant']} @ {booking['date']} {booking['time']}")
    except Exception as e:
        print(f"✗ 查询失败: {e}")
    
    context1.print_audit_log()
    
    # 场景2：普通用户尝试查询他人数据（应失败）
    print("\n\n【场景2】普通用户尝试查询他人数据（应失败）")
    print("-"*80)
    
    context2 = ToolContext(
        user=user1,
        data_source_config={"type": "mysql"}
    )
    
    try:
        result = tool_get.execute(context2, {
            "user_id": "user_456"  # 不是用户自己
        })
        print(f"\n✓ 查询成功 (不应该成功!)")
    except PermissionError as e:
        print(f"\n✓ 正确地被拒绝: {e}")
    
    context2.print_audit_log()
    
    # 场景3：管理员查询任何用户的数据（应成功）
    print("\n\n【场景3】管理员查询任何用户的数据（应成功）")
    print("-"*80)
    
    admin = User(
        id="admin_001",
        name="李四",
        role="admin",
        permission_level=PermissionLevel.ADMIN
    )
    
    context3 = ToolContext(
        user=admin,
        data_source_config={"type": "mysql"}
    )
    
    try:
        result = tool_get.execute(context3, {
            "user_id": "user_456"
        })
        print(f"\n✓ 查询成功 (管理员权限)")
        print(f"  - 预订数量: {result['count']}")
    except Exception as e:
        print(f"✗ 查询失败: {e}")
    
    context3.print_audit_log()
    
    # 场景4：普通用户取消自己的预订（应成功但需要提升权限）
    print("\n\n【场景4】普通用户尝试取消预订（权限不足）")
    print("-"*80)
    
    context4 = ToolContext(
        user=user1,
        data_source_config={"type": "mysql"}
    )
    
    tool_cancel = CancelBookingTool()
    
    try:
        result = tool_cancel.execute(context4, {
            "booking_id": "book_001",
            "user_id": "user_123",
            "reason": "工作日期冲突"  # 新增：共享资源操作必须提供原因
        })
        print(f"\n✓ 取消成功")
    except PermissionError as e:
        print(f"\n✓ 正确地被拒绝（权限不足）: {e}")
    
    context4.print_audit_log()
    
    # 场景5：主持人取消用户的预订（应成功）
    print("\n\n【场景5】主持人取消用户的预订（应成功）")
    print("-"*80)
    
    moderator = User(
        id="mod_001",
        name="王五",
        role="moderator",
        permission_level=PermissionLevel.MODERATOR
    )
    
    context5 = ToolContext(
        user=moderator,
        data_source_config={"type": "mysql"}
    )
    
    try:
        result = tool_cancel.execute(context5, {
            "booking_id": "book_001",
            "user_id": "user_123",
            "reason": "管理员代理取消"  # 新增：共享资源操作必须提供原因
        })
        print(f"\n✓ 取消成功 (主持人权限)")
        print(f"  - 受影响行数: {result['affected_rows']}")
    except Exception as e:
        print(f"✗ 取消失败: {e}")
    
    context5.print_audit_log()
    
    # 场景6：普通用户修改自己的信息（私人数据）
    print("\n\n【场景6】普通用户修改自己的账户信息（私人数据）")
    print("-"*80)
    
    context6 = ToolContext(
        user=user1,
        data_source_config={"type": "mysql"}
    )
    
    tool_update = UpdateUserInfoTool()
    
    try:
        result = tool_update.execute(context6, {
            "user_id": "user_123",
            "fields": {
                "phone": "13888888888",
                "email": "zhangsan@example.com"
            }
        })
        print(f"\n✓ 更新成功 (私人数据，最小验证)")
        print(f"  - 修改字段: {result['updated_fields']}")
        print(f"  - 受影响行数: {result['affected_rows']}")
    except Exception as e:
        print(f"✗ 更新失败: {e}")
    
    context6.print_audit_log()
    
    # 场景7：普通用户尝试修改他人信息（应失败）
    print("\n\n【场景7】普通用户尝试修改他人信息（应失败）")
    print("-"*80)
    
    context7 = ToolContext(
        user=user1,
        data_source_config={"type": "mysql"}
    )
    
    try:
        result = tool_update.execute(context7, {
            "user_id": "user_456",  # 不是用户自己
            "fields": {"phone": "13999999999"}
        })
        print(f"\n✓ 更新成功 (不应该成功!)")
    except PermissionError as e:
        print(f"\n✓ 正确地被拒绝: {e}")
    
    context7.print_audit_log()
    
    # 总结
    print("\n\n" + "="*80)
    print("✨ 演示总结")
    print("="*80)
    print("""
✅ 实现的三种操作流程：
  1. 【私人数据】读取预订、修改账户信息 
     - 流程：权限检查 → 所有权检查 → 执行
     - 特点：最小验证，无需原因记录
  
  2. 【共享资源】取消预订
     - 流程：权限检查 → 所有权检查 → 原因强制 → 状态转移 → 通知利益方
     - 特点：中等验证，必需原因，记录历史
  
  3. 【公共数据】（见 tool_types_implementation.py）
     - 流程：权限检查 → 所有权检查 → 证明强制 → 创建提案 → 审核流程
     - 特点：完整验证，需要管理员审批

✅ 实现的安全特性：
  1. 权限检查 - 根据用户角色控制访问
  2. 前置条件验证 - 取消前检查预订状态
  3. 所有权验证 - 用户只能操作自己的数据
  4. 审计日志 - 所有操作被记录和追踪
  5. 数据源抽象 - 工具不关心具体数据库类型

✅ 可复用性：
  - 同一个工具在不同权限下表现不同
  - 支持多种数据源配置
  - 参数化的表名和查询条件
  - 易于集成到 LangGraph

🔐 安全优势：
  - 最小权限原则
  - 审计追踪
  - 前置条件检查
  - 数据所有权验证

✨ 操作分类的核心优势：
  - 不同操作类型使用不同的安全策略
  - 代码更清晰，责任更明确
  - 业务需求（reason recording, 通知等）自动集成
  - 易于扩展新工具和操作类型
""")



if __name__ == "__main__":
    demo()
