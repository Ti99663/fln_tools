"""
操作类型分类在实际工具中的应用

展示如何在 SecureTool 中区分处理不同类型的操作
"""

# ============================================================================
# 实际应用示例：基于操作类型的工具实现
# ============================================================================

"""
【问题分析】

用户指出：
1. 取消预订操作
   - 不是直接删除数据库信息
   - 而是标记 status=true（可预订） 或 status='cancelled'
   - 同时记录取消原因
   
2. 修改用户自定义信息
   - 只需核验是本人操作
   - 按照本人指令去修改
   
3. 公共数据处理
   - 需要格外注意
   - 需要一套合适的处理方案
   
4. 私人数据/资源
   - 只需核验是本人操作即可


【解决方案】

使用操作类型分类，在 SecureTool 基类中实现不同的处理流程：

    SecureTool (基类)
        ├─ PrivateDataTool (私人数据)
        │   ├─ UpdatePersonalInfoTool
        │   └─ DeletePersonalDataTool
        │
        ├─ SharedResourceTool (共享资源)  
        │   ├─ CancelBookingTool
        │   ├─ ReleaseResourceTool
        │   └─ PauseServiceTool
        │
        └─ PublicDataTool (公共数据)
            ├─ ModifyRestaurantInfoTool
            ├─ CreatePromotionTool
            └─ ApproveListingTool


【执行流程对比】

┌─────────────────────────────────────────────────────────────────────────────┐
│                   三种不同类型操作的执行流程                                 │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  私人数据工具流程 (PrivateDataTool)                                          │
│  ────────────────────────────────────                                       │
│  1. 权限检查 ✓                                                               │
│  2. 身份验证 → 确认是本人 ✓                                                  │
│  3. 所有权检查 → 验证是本人的数据 ✓                                          │
│  4. 执行操作 → UPDATE 或 DELETE ✓                                            │
│  5. 记录审计日志 ✓                                                           │
│  ─────────────────────────────────                                          │
│  ✗ 无需：原因记录 / 审核流程                                                 │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  共享资源工具流程 (SharedResourceTool)                                       │
│  ──────────────────────────────────                                         │
│  1. 权限检查 ✓                                                               │
│  2. 身份验证 → 确认是本人 ✓                                                  │
│  3. 所有权检查 → 验证是本人的资源 ✓                                          │
│  4. 状态验证 → 检查当前状态是否允许操作 ✓                                   │
│  5. 收集操作原因 → 为何取消/释放/暂停 ✓                                     │
│  6. 执行操作 → UPDATE status, reason, timestamp ✓                           │
│  7. 通知相关方 → 如发送通知给餐厅 ✓                                         │
│  8. 记录审计日志（含原因）✓                                                 │
│  ──────────────────────────────────                                         │
│  ✗ 无需：审核流程                                                            │
│  ✓ 保留历史：通过 UPDATE 而非 DELETE                                         │
│                                                                              │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  公共数据工具流程 (PublicDataTool)                                           │
│  ───────────────────────────────────                                        │
│  1. 权限检查 ✓                                                               │
│  2. 身份验证 ✓                                                               │
│  3. 所有权检查 ✓                                                             │
│  4. 状态验证 ✓                                                               │
│  5. 收集修改原因/证明 → 为何修改及提供证据 ✓                                │
│  6. 创建修改提案 → 不直接修改，生成待审核记录 ✓                             │
│  7. 提交给审核队列 ✓                                                         │
│  8. 发送通知给管理员 ✓                                                       │
│  9. 记录审计日志（含完整证明材料）✓                                         │
│  ───────────────────────────────────                                        │
│  ✓ 需要审核流程：等待管理员批准                                              │
│  ✓ 返回值：proposal_id, 状态为 pending_approval                              │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
"""

from enum import Enum
from typing import Dict, Any, Optional, Callable
from abc import abstractmethod
from dataclasses import dataclass
from datetime import datetime


# ============================================================================
# 基础类定义
# ============================================================================

class DataOwnershipType(Enum):
    """数据所有权类型"""
    PRIVATE = "private"        # 私人数据
    SHARED = "shared"          # 共享资源
    PUBLIC = "public"          # 公共数据


class SecureTool:
    """所有工具的基类 - 定义共同的安全流程"""
    
    def __init__(self, name: str, data_ownership: DataOwnershipType):
        self.name = name
        self.data_ownership = data_ownership
    
    def execute(self, context: Any, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """工具执行的统一入口"""
        print(f"\n🔐 执行工具: {self.name}")
        print(f"   数据类型: {self.data_ownership.value}")
        
        try:
            # 步骤1：权限检查（所有工具必做）
            self._check_permission(context)
            
            # 步骤2：通用验证
            self._validate_user_authentication(context)
            
            # 步骤3：根据数据类型执行特定流程
            if self.data_ownership == DataOwnershipType.PRIVATE:
                return self._execute_private_data_flow(context, inputs)
            elif self.data_ownership == DataOwnershipType.SHARED:
                return self._execute_shared_resource_flow(context, inputs)
            elif self.data_ownership == DataOwnershipType.PUBLIC:
                return self._execute_public_data_flow(context, inputs)
        
        except Exception as e:
            self._log_error(context, str(e))
            raise
    
    # ========================================================================
    # 通用步骤
    # ========================================================================
    
    def _check_permission(self, context):
        """步骤1：权限检查"""
        print("   [1] 权限检查 ✓")
    
    def _validate_user_authentication(self, context):
        """步骤2：用户身份验证"""
        print("   [2] 身份验证 ✓")
        if not context.user:
            raise PermissionError("用户未登录")
    
    def _log_error(self, context, error_msg):
        """记录错误"""
        print(f"   [❌] 错误: {error_msg}")
    
    # ========================================================================
    # 私人数据流程
    # ========================================================================
    
    def _execute_private_data_flow(self, context, inputs) -> Dict[str, Any]:
        """
        私人数据流程：身份验证 → 所有权检查 → 直接更新
        """
        print("   📝 执行流程: 私人数据")
        
        # 步骤3：所有权检查
        self._check_data_ownership(context, inputs)
        print("   [3] 所有权检查 ✓")
        
        # 步骤4：执行业务逻辑
        result = self._execute_private_impl(context, inputs)
        print("   [4] 数据更新成功 ✓")
        
        # 步骤5：审计日志
        print("   [5] 审计日志 ✓")
        self._log_audit(context, "PRIVATE_DATA_OPERATION", "success", inputs)
        
        return result
    
    def _check_data_ownership(self, context, inputs):
        """检查所有权 - 用户只能操作自己的数据"""
        target_user_id = inputs.get("user_id")
        if target_user_id != context.user.id:
            raise PermissionError("无法修改其他用户的数据")
    
    def _execute_private_impl(self, context, inputs):
        """执行私人数据具体操作 - 由子类实现"""
        raise NotImplementedError
    
    # ========================================================================
    # 共享资源流程
    # ========================================================================
    
    def _execute_shared_resource_flow(self, context, inputs) -> Dict[str, Any]:
        """
        共享资源流程：
        身份验证 → 所有权检查 → 状态验证 → 收集原因 → 状态转移 → 通知 → 日志
        """
        print("   📦 执行流程: 共享资源")
        
        # 步骤3：所有权检查
        self._check_data_ownership(context, inputs)
        print("   [3] 所有权检查 ✓")
        
        # 步骤4：状态验证
        self._validate_resource_state(context, inputs)
        print("   [4] 状态验证 ✓")
        
        # 步骤5：收集原因
        reason = inputs.get("reason", "")
        if not reason:
            raise ValueError("必须提供操作原因")
        print(f"   [5] 原因记录 ✓ ('{reason[:30]}...')")
        
        # 步骤6：执行业务逻辑
        result = self._execute_shared_impl(context, inputs)
        print("   [6] 状态转移成功 ✓")
        
        # 步骤7：通知相关方
        self._notify_stakeholders(context, inputs)
        print("   [7] 通知相关方 ✓")
        
        # 步骤8：审计日志
        print("   [8] 审计日志（含原因）✓")
        self._log_audit(context, "SHARED_RESOURCE_OPERATION", "success", inputs)
        
        return result
    
    def _validate_resource_state(self, context, inputs):
        """验证资源当前状态 - 由子类实现"""
        raise NotImplementedError
    
    def _notify_stakeholders(self, context, inputs):
        """通知利益相关方 - 如通知餐厅"""
        # 模拟发送通知
        print("      └─ 发送通知...")
    
    def _execute_shared_impl(self, context, inputs):
        """执行共享资源具体操作 - 由子类实现"""
        raise NotImplementedError
    
    # ========================================================================
    # 公共数据流程
    # ========================================================================
    
    def _execute_public_data_flow(self, context, inputs) -> Dict[str, Any]:
        """
        公共数据流程：
        身份验证 → 所有权检查 → 状态验证 → 收集证明 → 创建提案 → 提交审核 → 日志
        """
        print("   🏢 执行流程: 公共数据")
        
        # 步骤3：所有权检查
        self._check_data_ownership(context, inputs)
        print("   [3] 所有权检查 ✓")
        
        # 步骤4：状态验证
        self._validate_resource_state(context, inputs)
        print("   [4] 状态验证 ✓")
        
        # 步骤5：收集修改证明
        evidence = inputs.get("evidence", "")
        if not evidence:
            raise ValueError("必须提供修改原因/证明")
        print(f"   [5] 证明材料 ✓ ('{evidence[:30]}...')")
        
        # 步骤6：创建修改提案（不直接修改！）
        proposal_id = self._create_proposal(context, inputs)
        print(f"   [6] 创建提案 ✓ (proposal: {proposal_id})")
        
        # 步骤7：提交审核
        self._submit_for_approval(context, proposal_id, inputs)
        print("   [7] 提交审核 ✓")
        
        # 步骤8：通知审核团队
        self._notify_approval_team(context, proposal_id)
        print("   [8] 通知审核团队 ✓")
        
        # 步骤9：审计日志
        print("   [9] 审计日志（完整记录）✓")
        self._log_audit(context, "PUBLIC_DATA_PROPOSAL", "pending_approval", inputs)
        
        return {
            "success": True,
            "proposal_id": proposal_id,
            "status": "pending_approval",
            "message": "修改提案已提交审核，等待管理员批准"
        }
    
    def _create_proposal(self, context, inputs) -> str:
        """创建修改提案 - 返回 proposal_id"""
        proposal_id = f"prop_{datetime.now().strftime('%Y%m%d%H%M%S')}"
        return proposal_id
    
    def _submit_for_approval(self, context, proposal_id: str, inputs):
        """提交给审核队列"""
        # 模拟提交到审核系统
        pass
    
    def _notify_approval_team(self, context, proposal_id: str):
        """通知审核团队"""
        # 模拟发送通知给管理员
        print(f"      └─ 通知管理员检查提案 {proposal_id}...")
    
    # ========================================================================
    # 审计日志
    # ========================================================================
    
    def _log_audit(self, context, action: str, status: str, details: Dict):
        """记录审计日志"""
        # 这里会调用 context.log_action
        pass


# ============================================================================
# 具体工具实现示例
# ============================================================================

class CancelBookingTool(SecureTool):
    """取消预订 - 共享资源操作"""
    
    def __init__(self):
        super().__init__("cancel_booking", DataOwnershipType.SHARED)
    
    def _validate_resource_state(self, context, inputs):
        """检查预订状态"""
        booking_status = "confirmed"  # 模拟获取
        if booking_status in ["cancelled", "completed"]:
            raise ValueError(f"无法取消状态为 {booking_status} 的预订")
    
    def _execute_shared_impl(self, context, inputs) -> Dict[str, Any]:
        """执行取消预订"""
        booking_id = inputs.get("booking_id")
        reason = inputs.get("reason")
        
        # 关键：标记状态而非删除
        # UPDATE bookings 
        # SET status='cancelled', cancel_reason=?, cancelled_at=NOW()
        # WHERE id = ?
        
        return {
            "success": True,
            "booking_id": booking_id,
            "action": "status_marked_as_cancelled",  # 不是 DELETE
            "update_fields": {
                "status": "cancelled",
                "cancel_reason": reason,
                "cancelled_at": datetime.now().isoformat()
            }
        }


class UpdateUserInfoTool(SecureTool):
    """更新用户信息 - 私人数据操作"""
    
    def __init__(self):
        super().__init__("update_user_info", DataOwnershipType.PRIVATE)
    
    def _execute_private_impl(self, context, inputs) -> Dict[str, Any]:
        """执行用户信息更新"""
        user_id = inputs.get("user_id")
        updates = inputs.get("updates", {})
        
        # 直接更新用户信息
        # UPDATE users SET phone=?, address=? WHERE id=?
        
        return {
            "success": True,
            "user_id": user_id,
            "action": "user_info_updated",
            "updated_fields": list(updates.keys())
        }


class ModifyRestaurantInfoTool(SecureTool):
    """修改餐厅信息 - 公共数据操作"""
    
    def __init__(self):
        super().__init__("modify_restaurant_info", DataOwnershipType.PUBLIC)
    
    def _validate_resource_state(self, context, inputs):
        """检查餐厅状态"""
        restaurant_id = inputs.get("restaurant_id")
        status = "active"  # 模拟获取
        if status in ["suspended", "closed"]:
            raise ValueError(f"无法修改状态为 {status} 的餐厅")
    
    def _execute_shared_impl(self, context, inputs):
        # 这个方法不会被调用，因为 public data 有特殊流程
        pass


# ============================================================================
# 演示
# ============================================================================

@dataclass
class MockContext:
    """模拟执行上下文"""
    class User:
        id = "user_123"
    user = User()
    def log_action(self, *args, **kwargs):
        pass


def demo():
    print("\n" + "="*80)
    print("🎯 操作类型分类在实际工具中的应用")
    print("="*80)
    
    context = MockContext()
    
    # ========================================================================
    # 演示1：私人数据 - 更新用户信息
    # ========================================================================
    print("\n【演示1】私人数据操作 - 用户修改自己的电话号码")
    print("-"*80)
    
    tool1 = UpdateUserInfoTool()
    result1 = tool1.execute(context, {
        "user_id": "user_123",
        "updates": {
            "phone": "13800138000"
        }
    })
    print(f"\n✅ 结果: {result1}\n")
    
    # ========================================================================
    # 演示2：共享资源 - 取消预订
    # ========================================================================
    print("\n【演示2】共享资源操作 - 用户取消预订")
    print("-"*80)
    
    tool2 = CancelBookingTool()
    result2 = tool2.execute(context, {
        "booking_id": "book_001",
        "user_id": "user_123",
        "reason": "日期冲突，无法准时到达"
    })
    print(f"\n✅ 结果: {result2}\n")
    
    # ========================================================================
    # 演示3：公共数据 - 修改餐厅信息
    # ========================================================================
    print("\n【演示3】公共数据操作 - 餐厅主修改餐厅信息")
    print("-"*80)
    
    tool3 = ModifyRestaurantInfoTool()
    result3 = tool3.execute(context, {
        "restaurant_id": "rest_001",
        "user_id": "user_123",
        "updates": {
            "opening_hours": "11:00-23:00",
            "capacity": 150
        },
        "evidence": "餐厅完成装修，座位数增加"
    })
    print(f"\n✅ 结果: {result3}\n")


if __name__ == "__main__":
    demo()
