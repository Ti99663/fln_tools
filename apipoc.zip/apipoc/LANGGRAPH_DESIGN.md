# LangGraph驱动的Agent工作流架构设计

## 核心思想：有状态的工作流管理

### 传统Agent vs LangGraph Agent

```
【传统Agent】
用户输入 → 选择工具 → 调用工具 → 返回结果 ✘ 没有状态，不适合复杂流程

【LangGraph Agent】
用户输入 
  ↓
初始化State（存储整个工作流的状态）
  ↓
执行相关的Nodes（每个Node可调用多个工具）
  ↓
基于条件进行routing（条件分支）
  ↓
更新State并继续
  ↓
返回最终结果 ✅ 完整的状态管理
```

## 复杂场景分析

### 场景 1: 取消餐厅预订

```
用户输入: "我要取消之前预定的餐厅"

工作流：
┌─ State: {"user_phone": "13800138000", "action": "cancel_booking", ...}
│
├─ Node 1: 查询预定历史
│  └─ 调用: get_booking_history(phone=user_phone)
│  └─ 更新State: 添加 bookings 字段
│
├─ Decision: 是否找到预定?
│  ├─ YES → 继续
│  └─ NO → 返回错误信息
│
├─ Node 2: 取消预定
│  └─ 调用: cancel_booking(booking_id=state.bookings[0].id)
│  └─ 更新State: 标记为 cancelled=True
│
├─ Node 3: 发送取消通知
│  └─ 调用: send_sms(phone=user_phone, message="已取消预定...")
│  └─ 更新State: notification_sent=True
│
└─ Node 4: 生成响应
   └─ 基于State生成用户友好的响应
```

### 场景 2: 在线购物流程

```
用户输入: "帮我在Amazon上搜索iPhone 15，然后下单寄到我家"

工作流：
┌─ State: {
│   "user_id": "...",
│   "website": "amazon",
│   "search_query": "iPhone 15",
│   "delivery_address": "...",
│   "steps_completed": []
│ }
│
├─ Node 1: 网站登录
│  └─ 调用: login(website="amazon", credentials=...)
│  └─ 更新State: session_token
│
├─ Node 2: 搜索商品
│  └─ 调用: search_products(query="iPhone 15", site="amazon")
│  └─ 更新State: search_results = [...]
│
├─ Node 3: 显示选项给用户（可选，需要用户确认）
│  └─ 如果有多个结果，让用户选择
│  └─ 更新State: selected_product
│
├─ Node 4: 查询收货地址
│  └─ 调用: get_user_addresses(user_id)
│  └─ 更新State: available_addresses
│
├─ Node 5: 确认地址
│  └─ 使用 state.delivery_address
│  └─ 更新State: confirmed_address
│
├─ Node 6: 支付
│  └─ 调用: process_payment(
│       amount=product.price,
│       payment_method=user_payment_method,
│       order_id=generated_order_id
│     )
│  └─ 更新State: payment_status="completed", transaction_id
│
├─ Decision: 支付成功?
│  ├─ YES → 继续
│  └─ NO → 返回错误，跳转到错误处理Node
│
├─ Node 7: 创建订单
│  └─ 调用: create_order(
│       product_id=selected_product.id,
│       address=confirmed_address,
│       payment_id=transaction_id
│     )
│  └─ 更新State: order_id, order_status="confirmed"
│
└─ Node 8: 发送确认短信
   └─ 调用: send_sms(
        phone=user_phone,
        message="订单已成功创建... 订单号: {order_id}"
      )
   └─ 更新State: notification_sent=True
```

## State设计

### State对象结构

```python
class AgentState(TypedDict):
    """Agent工作流状态"""
    # 基础信息
    user_id: str                    # 用户ID
    user_phone: str                 # 用户电话
    
    # 当前工作流信息
    workflow_type: str              # 工作流类型（booking, shopping, cancellation等）
    current_step: int               # 当前步骤
    max_steps: int                  # 最大步骤数（防止无限循环）
    
    # 用户输入和意图
    user_input: str                 # 原始用户输入
    intent: str                     # 识别的用户意图
    
    # 工作流执行状态
    executed_nodes: List[str]       # 已执行的节点列表
    node_results: Dict[str, Any]    # 每个节点的执行结果
    
    # 工具调用记录
    tool_calls: List[Dict]          # 所有工具调用的记录
    tool_errors: List[str]          # 工具执行的错误列表
    
    # 逻辑变量
    is_success: bool                # 是否成功
    error_message: str              # 错误信息
    
    # 上下文数据（动态字段）
    context: Dict[str, Any]         # 存储工作流相关的任何数据
                                    # 如：bookings, search_results, 
                                    #     selected_product, addresses等
```

## Node设计

### Node类型

```python
from typing import Callable

class Node:
    """工作流节点"""
    
    def __init__(
        self,
        name: str,
        fn: Callable[[AgentState], AgentState],
        input_keys: List[str] = None,
        output_keys: List[str] = None
    ):
        self.name = name
        self.fn = fn  # 节点的执行函数
        self.input_keys = input_keys or []
        self.output_keys = output_keys or []
    
    async def execute(self, state: AgentState) -> AgentState:
        """执行节点"""
        print(f"\n▶ 执行Node: {self.name}")
        state["executed_nodes"].append(self.name)
        state["current_step"] += 1
        
        try:
            # 执行节点函数
            state = self.fn(state)
            print(f"✅ {self.name} 完成")
            return state
        except Exception as e:
            print(f"❌ {self.name} 失败: {str(e)}")
            state["error_message"] = str(e)
            state["tool_errors"].append(f"{self.name}: {str(e)}")
            raise
```

### Edge设计（节点间的连接）

```python
class Edge:
    """节点间的连接和路由"""
    
    def __init__(
        self,
        source_node: str,
        target_node: str,
        condition: Callable[[AgentState], bool] = None
    ):
        self.source = source_node
        self.target = target_node
        self.condition = condition or (lambda state: True)  # 默认总是执行
    
    def should_execute(self, state: AgentState) -> bool:
        """判断是否应该执行这条边"""
        return self.condition(state)
```

## Graph定义

```python
class AgentGraph:
    """工作流图"""
    
    def __init__(self):
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []
        self.entry_point: str = None
        self.end_points: List[str] = []
    
    def add_node(self, name: str, fn: Callable):
        """添加节点"""
        self.nodes[name] = Node(name, fn)
    
    def add_edge(self, source: str, target: str, condition: Callable = None):
        """添加有向边"""
        edge = Edge(source, target, condition)
        self.edges.append(edge)
    
    def set_entry_point(self, node_name: str):
        """设置入口节点"""
        self.entry_point = node_name
    
    def set_end_point(self, node_name: str):
        """设置出口节点"""
        self.end_points.append(node_name)
    
    async def execute(self, state: AgentState) -> AgentState:
        """执行整个工作流"""
        current_node = self.entry_point
        
        while current_node and current_node not in self.end_points:
            # 执行当前节点
            state = await self.nodes[current_node].execute(state)
            
            # 检查步骤限制（防止无限循环）
            if state["current_step"] >= state["max_steps"]:
                state["error_message"] = "超出最大步骤数，可能陷入循环"
                break
            
            # 查找下一个节点
            next_node = None
            for edge in self.edges:
                if edge.source == current_node and edge.should_execute(state):
                    next_node = edge.target
                    break
            
            current_node = next_node
        
        return state
```

## 实现示例：取消预订工作流

```python
# 创建图
graph = AgentGraph()

# Node 1: 查询预定历史
def node_get_bookings(state: AgentState) -> AgentState:
    user_phone = state["context"].get("user_phone")
    bookings = call_tool("get_booking_history", {"phone": user_phone})
    state["context"]["bookings"] = bookings
    state["node_results"]["get_bookings"] = bookings
    return state

# Node 2: 确认取消
def node_confirm_cancellation(state: AgentState) -> AgentState:
    bookings = state["context"].get("bookings", [])
    if not bookings:
        raise Exception("没有预定记录")
    
    booking_to_cancel = bookings[0]  # 取最新的
    state["context"]["booking_to_cancel"] = booking_to_cancel
    return state

# Node 3: 执行取消
def node_cancel_booking(state: AgentState) -> AgentState:
    booking = state["context"]["booking_to_cancel"]
    result = call_tool("cancel_booking", {"booking_id": booking["id"]})
    state["context"]["cancellation_result"] = result
    state["node_results"]["cancel_booking"] = result
    return state

# Node 4: 发送通知
def node_send_notification(state: AgentState) -> AgentState:
    user_phone = state["context"]["user_phone"]
    booking = state["context"]["booking_to_cancel"]
    message = f"您已成功取消在{booking['restaurant']}的预定"
    
    result = call_tool("send_sms", {"phone": user_phone, "message": message})
    state["context"]["notification_sent"] = True
    state["node_results"]["send_sms"] = result
    return state

# 添加节点
graph.add_node("get_bookings", node_get_bookings)
graph.add_node("confirm_cancellation", node_confirm_cancellation)
graph.add_node("cancel_booking", node_cancel_booking)
graph.add_node("send_notification", node_send_notification)

# 添加边（流程连接）
graph.add_edge("get_bookings", "confirm_cancellation")
graph.add_edge("confirm_cancellation", "cancel_booking", 
               condition=lambda s: len(s["context"].get("bookings", [])) > 0)
graph.add_edge("cancel_booking", "send_notification")

# 设置入口和出口
graph.set_entry_point("get_bookings")
graph.set_end_point("send_notification")

# 执行
state = {
    "user_id": "user123",
    "user_phone": "13800138000",
    "workflow_type": "cancellation",
    "current_step": 0,
    "max_steps": 10,
    "user_input": "我要取消预定",
    "executed_nodes": [],
    "node_results": {},
    "tool_calls": [],
    "tool_errors": [],
    "is_success": False,
    "error_message": "",
    "context": {"user_phone": "13800138000"}
}

result_state = await graph.execute(state)
```

## 与多任务系统的集成

### 对比

```
【Phase 2: 多任务系统】
├─ 识别多个任务
├─ 分析依赖关系
└─ 并行/顺序执行 ← 简单的流程控制

【Phase 3: LangGraph系统】 (现在)
├─ 有状态的工作流
├─ 复杂的条件分支
├─ 工具组合和数据流动 ← 高级的流程控制
├─ 循环和错误处理
└─ 动态的State管理
```

### 升级路径

```python
# Phase 2 (当前)
if "然后" in user_input:
    task_sequence = [task1, task2, task3]
    for task in task_sequence:
        execute_task(task)

# Phase 3 (LangGraph)
graph = build_workflow_graph(user_input)  # 根据意图构建图
state = initialize_state(user_input)      # 初始化状态
result = await graph.execute(state)       # 执行有状态工作流
```

## 优势

✅ **State Management**: 完整的状态追踪
✅ **Complex Workflows**: 支持循环、条件分支、错误处理
✅ **Data Flow**: 工具间可以传递和使用彼此的结果
✅ **Observability**: 完整的执行日志和调试信息
✅ **Flexibility**: 易于添加新节点、修改流程
✅ **Error Handling**: 每个节点可独立处理错误

## 实现步骤

### 第一步：构建基础框架
- [ ] 定义 AgentState (TypedDict)
- [ ] 实现 Node 类
- [ ] 实现 Edge 类
- [ ] 实现 Graph 类

### 第二步：构建工具层
- [ ] 工具定义（Tool类）
- [ ] 工具调用包装器（记录调用、处理错误）
- [ ] 工具结果处理

### 第三步：Graph构建器
- [ ] 从用户输入生成Graph
- [ ] 根据意图选择合适的Node组合
- [ ] 自动连接Edge

### 第四步：集成和测试
- [ ] 集成现有的Agent
- [ ] 测试各种工作流场景
- [ ] 性能优化

