import requests
import json
from typing import Any, Dict, List, Optional
from datetime import datetime

# 可选导入 anthropic（如果需要使用 Claude，请运行: pip install anthropic）
try:
    import anthropic
except ImportError:
    anthropic = None

# ============ LLM 配置 ============
# 使用 Anthropic 的免费试用或使用其他免费 LLM 接口
# 如果没有 API Key，可以改用本地 Ollama

class LLMClient:
    """LLM 客户端 - 支持多个免费接口"""
    
    def __init__(self, api_type: str = "ollama", api_key: Optional[str] = None, 
                 api_endpoint: Optional[str] = None, model: Optional[str] = None):
        """
        api_type: "ollama" (本地), "anthropic", "deepseek", "ssrai"
        api_key: API 密钥
        api_endpoint: SSRAI 端点 URL
        model: 模型名称（SSRAI 时使用，如 "gpt-4o"；Ollama 时为空会自动选择）
        """
        self.api_type = api_type
        self.api_key = api_key
        self.api_endpoint = api_endpoint
        # Ollama 时 model 默认为 None（自动选择），其他 API 类型默认为 "gpt-4o"
        if api_type == "ollama":
            self.model = model  # Ollama 时不设置默认值
        else:
            self.model = model or "gpt-4o"
        
        if api_type == "anthropic" and not api_key:
            raise ValueError("Anthropic 需要 API Key")
        
        if api_type == "deepseek" and not api_key:
            raise ValueError("DeepSeek 需要 API Key")
        
        if api_type == "ssrai":
            if not api_key:
                raise ValueError("SSRAI 需要 API Key")
            if not api_endpoint:
                raise ValueError("SSRAI 需要 API 端点 URL")
    
    def call(self, prompt: str, tools_context: str = "") -> str:
        """调用 LLM"""
        
        if self.api_type == "ollama":
            return self._call_ollama(prompt, tools_context)
        elif self.api_type == "anthropic":
            return self._call_anthropic(prompt, tools_context)
        elif self.api_type == "deepseek":
            return self._call_deepseek(prompt, tools_context)
        elif self.api_type == "ssrai":
            return self._call_ssrai(prompt, tools_context)
        else:
            raise ValueError(f"不支持的 LLM 类型: {self.api_type}")
    
    def _call_ollama(self, prompt: str, tools_context: str) -> str:
        """使用本地 Ollama（需要先启动 ollama serve）
        
        ⚠️ 性能提示：
        - qwen3:4b: JSON 分解 需要 60-120+ 秒（太慢）
        - tinyllama: JSON 分解 需要 8-15 秒（推荐）
        
        要切换模型，请运行: ollama pull tinyllama
        """
        try:
            # 1. 获取可用模型列表
            tags_response = requests.get(
                "http://localhost:11434/api/tags",
                timeout=5
            )
            
            if tags_response.status_code != 200:
                raise Exception(f"Ollama API 错误 (tags): {tags_response.status_code}")
            
            models = tags_response.json().get("models", [])
            if not models:
                raise Exception(
                    "Ollama 中没有模型。请运行: ollama pull qwen:4b"
                )
            
            # 2. 使用第一个可用模型（或 self.model 如果指定了）
            model_name = self.model or models[0]["name"]
            print(f"[DEBUG] 使用模型: {model_name}")  # DEBUG
            print(f"[DEBUG] 请求内容: {{'model': '{model_name}', 'prompt': '...', 'stream': False, 'temperature': 0.0}}")  # DEBUG
            
            # 3. 调用模型
            response = requests.post(
                "http://localhost:11434/api/generate",
                json={
                    "model": model_name,
                    "prompt": f"{tools_context}\n\n{prompt}",
                    "stream": False,
                    "temperature": 0.0,
                },
                timeout=300  # 5 分钟超时（诊断发现 JSON 分解需要 2-3 分钟）
            )
            print(f"[DEBUG] 状态码: {response.status_code}")  # DEBUG
            print(f"[DEBUG] 响应内容: {response.text[:200]}")  # DEBUG
            
            if response.status_code == 200:
                return response.json()["response"]
            else:
                raise Exception(f"Ollama API 错误 (generate): {response.status_code}\nResponse: {response.text}")
        except requests.exceptions.ConnectionError:
            raise Exception(
                "无法连接到 Ollama。请先运行: ollama serve\n"
                "并下载模型: ollama pull qwen:4b"
            )
    
    def _call_anthropic(self, prompt: str, tools_context: str) -> str:
        """使用 Claude API (免费试用)"""
        if anthropic is None:
            raise ImportError(
                "Anthropic 库未安装。请运行: pip install anthropic"
            )
        
        client = anthropic.Anthropic(api_key=self.api_key)
        
        message = client.messages.create(
            model="claude-3-5-sonnet-20241022",
            max_tokens=1024,
            messages=[
                {
                    "role": "user",
                    "content": f"{tools_context}\n\n{prompt}"
                }
            ]
        )
        return message.content[0].text
    
    def _call_deepseek(self, prompt: str, tools_context: str) -> str:
        """使用 DeepSeek API"""
        response = requests.post(
            "https://api.deepseek.com/chat/completions",
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json"
            },
            json={
                "model": "deepseek-chat",
                "messages": [
                    {
                        "role": "system",
                        "content": tools_context
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                "temperature": 0.0,
                "max_tokens": 1024
            }
        )
        if response.status_code == 200:
            return response.json()["choices"][0]["message"]["content"]
        else:
            raise Exception(f"DeepSeek API 错误: {response.status_code}")
    
    def _call_ssrai(self, prompt: str, tools_context: str) -> str:
        """使用 SSRAI API（支持 GPT-4o 等）"""
        try:
            response = requests.post(
                f"{self.api_endpoint}/chat/completions",
                headers={
                    "Authorization": f"Bearer {self.api_key}",
                    "Content-Type": "application/json"
                },
                json={
                    "model": self.model,
                    "messages": [
                        {
                            "role": "system",
                            "content": tools_context
                        },
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ],
                    "temperature": 0.0,
                    "max_tokens": 1024
                }
            )
            if response.status_code == 200:
                return response.json()["choices"][0]["message"]["content"]
            else:
                error_msg = response.text
                raise Exception(f"SSRAI API 错误 ({response.status_code}): {error_msg}")
        except requests.exceptions.ConnectionError:
            raise Exception(
                f"无法连接到 SSRAI API: {self.api_endpoint}\n"
                "请检查 API 端点 URL 是否正确"
            )

# ============ Agent 核心 ============
class RestaurantAgent:
    """餐厅预订 Agent"""
    
    def __init__(self, llm_client: LLMClient, api_base_url: str = "http://127.0.0.1:8001"):
        self.llm = llm_client
        self.api_base_url = api_base_url
        self.tools = []
        self.conversation_history = []
        self._load_tools()
    
    def _load_tools(self):
        """从 API 服务器加载工具定义"""
        try:
            response = requests.get(f"{self.api_base_url}/tools")
            if response.status_code == 200:
                self.tools = response.json()["tools"]
                print(f"✓ 已加载 {len(self.tools)} 个工具")
            else:
                raise Exception("无法加载工具")
        except requests.exceptions.ConnectionError:
            raise Exception(
                f"无法连接到 API 服务器: {self.api_base_url}\n"
                "请先运行: python api_server.py"
            )
    
    def _format_tools_context(self) -> str:
        """格式化工具上下文 - 改进版prompting"""
        tools_text = """你是一个餐厅预订AI助手。

### 你可以使用的工具：
"""
        for tool in self.tools:
            tools_text += f"\n【{tool['name']}】 - {tool['description']}\n"
            tools_text += f"  参数: "
            params = tool['parameters']
            for param_name, param_info in params.items():
                required = "必需" if param_name in ['restaurant_name', 'date', 'location'] else "可选"
                tools_text += f"{param_name}({required}), "
            tools_text = tools_text.rstrip(", ") + "\n"
        
        # 多层次的格式要求
        tools_text += """

### 返回格式 - 必须严格遵守：
你必须返回一个JSON对象（或数组），不要返回任何其他文本。

单个任务：
{"tool": "工具名", "params": {"参数1": "值1", "参数2": "值2"}}

多个任务（如果用户有多个请求）：
{"tasks": [
  {"tool": "工具名1", "params": {...}},
  {"tool": "工具名2", "params": {...}}
]}

### 参数填写规则：
1. restaurant_name - 餐厅名称，如"金牌川菜馆"、"精品粤菜"
2. location - 地点，如"中关村"、"北京"、"上海"
3. cuisine_type - 菜系，如"川菜"、"粤菜"、"火锅"
4. date - 日期，格式为 YYYY-MM-DD，例如 "2026-03-28"
5. time - 时间，格式为 HH:MM，例如 "19:00"
6. people_count - 人数，整数，例如 4
7. customer_name - 客户名字
8. phone - 电话号码，11位数字

### 参数提取示例：
用户说："帮我在中关村找一家川菜馆"
返回：{"tool": "search_restaurants", "params": {"location": "中关村", "cuisine_type": "川菜"}}

用户说："查一下金牌川菜馆今天18点有没有4个人的空位"
返回：{"tool": "check_availability", "params": {"restaurant_name": "金牌川菜馆", "date": "2026-03-27"}}

用户说："帮我预订金牌川菜馆，明天19点，4人，叫张三，电话13800138000"
返回：{"tool": "make_booking", "params": {"restaurant_name": "金牌川菜馆", "date": "2026-03-28", "time": "19:00", "people_count": 4, "customer_name": "张三", "phone": "13800138000"}}

### 多任务例子：
用户说："先帮我搜索中关村的川菜，然后查一下有没有今天的空位"
返回：{"tasks": [
  {"tool": "search_restaurants", "params": {"location": "中关村", "cuisine_type": "川菜"}},
  {"tool": "check_availability", "params": {"restaurant_name": "金牌川菜馆", "date": "2026-03-27"}}
]}

### 重要提示：
- 只返回JSON，不要返回解释或其他文本
- 如果用户说"明天"，当前日期是2026-03-27，所以明天是2026-03-28
- 如果用户说"今天"，当前日期是2026-03-27
- 时间"19点"应该转换为"19:00"
"""
        return tools_text
    
    def _parse_llm_response(self, response: str) -> Dict[str, Any]:
        """解析 LLM 响应（改进参数提取 + 多任务支持）"""
        print(f"[DEBUG] 解析LLM响应...")
        
        # 首先尝试 JSON 解析
        try:
            start = response.find('{')
            end = response.rfind('}') + 1
            if start >= 0 and end > start:
                json_str = response[start:end]
                result = json.loads(json_str)
                
                # 处理多任务情况
                if "tasks" in result and isinstance(result["tasks"], list):
                    print(f"[DEBUG] ✓ 识别多任务: {len(result['tasks'])} 个任务")
                    # 分析任务依赖关系
                    dependencies = self._analyze_task_dependencies(result["tasks"])
                    result["dependencies"] = dependencies
                    return result
                
                # 处理单任务情况
                if "tool" in result and "params" in result:
                    if result["params"]:  # 参数不为空
                        print(f"[DEBUG] ✓ LLM成功提取参数: {result['params']}")
                        return result
                    else:  # 参数为空，使用智能提取补充
                        print(f"[DEBUG] LLM参数为空，使用智能提取补充")
                        tool_name = result["tool"]
                        params = self._extract_params_from_text(
                            self.conversation_history[-1]["content"], tool_name
                        )
                        result["params"] = params
                        return result
        except json.JSONDecodeError as e:
            print(f"[DEBUG] JSON解析失败: {str(e)}")

        # 如果 JSON 解析失败，使用启发式 + 参数提取
        print(f"[DEBUG] 使用启发式方法识别工具...")
        tool_name = None
        if "search_restaurants" in response.lower() or "搜索" in response:
            tool_name = "search_restaurants"
        elif "availability" in response.lower() or "可用" in response or "时间" in response:
            tool_name = "check_availability"
        elif "booking" in response.lower() or "预订" in response or "订位" in response:
            tool_name = "make_booking"
        elif "history" in response.lower() or "历史" in response:
            tool_name = "get_booking_history"

        if tool_name:
            # 智能提取参数
            params = self._extract_params_from_text(response, tool_name)
            return {"tool": tool_name, "params": params}

        print(f"[DEBUG] 无法识别工具")
        return None
    
    def _analyze_task_dependencies(self, tasks: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """分析任务间的依赖关系"""
        print(f"[DEBUG] 分析任务依赖关系...")
        user_input = self.conversation_history[-1]["content"] if self.conversation_history else ""
        
        dependencies = []
        
        # 关键词检测
        has_then = "然后" in user_input or "接着" in user_input or "再" in user_input
        has_parallel = "同时" in user_input or "分别" in user_input or "同步" in user_input
        has_if = "如果" in user_input or "当" in user_input
        
        if has_parallel and len(tasks) > 1:
            print(f"[DEBUG] 检测到并行任务")
            for i in range(len(tasks)-1):
                dependencies.append({
                    "from": i,
                    "to": i+1,
                    "type": "parallel"
                })
        elif has_then and len(tasks) > 1:
            print(f"[DEBUG] 检测到顺序任务")
            for i in range(len(tasks)-1):
                dependencies.append({
                    "from": i,
                    "to": i+1,
                    "type": "sequential"
                })
        
        return dependencies

    def _extract_params_from_text(self, text: str, tool_name: str) -> Dict[str, Any]:
        """从文本中智能提取参数"""
        print(f"[DEBUG] 提取参数 - 原始文本: '{text}'")
        print(f"[DEBUG] 提取参数 - 工具: {tool_name}")
        params = {}

        # 餐厅名称提取
        restaurant_keywords = ["金牌川菜馆", "川菜", "餐厅", "饭店"]
        for keyword in restaurant_keywords:
            if keyword in text:
                params["restaurant_name"] = "金牌川菜馆"
                print(f"[DEBUG] ✓ 找到餐厅: {keyword} -> 金牌川菜馆")
                break

        # 日期提取
        if "明天" in text:
            from datetime import datetime, timedelta
            tomorrow = datetime.now() + timedelta(days=1)
            params["date"] = tomorrow.strftime("%Y-%m-%d")
            print(f"[DEBUG] ✓ 找到日期: 明天 -> {params['date']}")
        elif "今天" in text:
            from datetime import datetime
            today = datetime.now()
            params["date"] = today.strftime("%Y-%m-%d")
            print(f"[DEBUG] ✓ 找到日期: 今天 -> {params['date']}")

        # 时间提取（支持 "19点" 和 "19:00" 两种格式）
        import re
        # 先尝试 "19点" 或 "19:30" 的格式
        time_match = re.search(r'(\d{1,2})[:：点](\d{2})?', text)
        if time_match:
            hour = time_match.group(1)
            minute = time_match.group(2) or "00"
            params["time"] = f"{int(hour):02d}:{minute}"
            print(f"[DEBUG] ✓ 找到时间: {time_match.group(0)} -> {params['time']}")

        # 人数提取
        people_match = re.search(r'(\d+)人', text)
        if people_match:
            params["people_count"] = int(people_match.group(1))
            print(f"[DEBUG] ✓ 找到人数: {people_match.group(0)} -> {params['people_count']}")

        # 姓名提取
        name_match = re.search(r'我叫([^\s，,。\.]+)', text)
        if name_match:
            params["customer_name"] = name_match.group(1)
            print(f"[DEBUG] ✓ 找到姓名: {name_match.group(0)} -> {params['customer_name']}")

        # 电话提取
        phone_match = re.search(r'(\d{11})', text)
        if phone_match:
            params["phone"] = phone_match.group(1)
            print(f"[DEBUG] ✓ 找到电话: {phone_match.group(0)} -> {params['phone']}")

        # 地点提取
        location_keywords = ["中关村", "北京", "上海", "深圳"]
        for location in location_keywords:
            if location in text:
                params["location"] = location
                print(f"[DEBUG] ✓ 找到地点: {location}")
                break

        # 菜系提取
        cuisine_keywords = ["川菜", "粤菜", "湘菜", "火锅", "海鲜"]
        for cuisine in cuisine_keywords:
            if cuisine in text:
                params["cuisine_type"] = cuisine
                print(f"[DEBUG] ✓ 找到菜系: {cuisine}")
                break

        print(f"[DEBUG] 智能提取参数: {params}")
        return params
    
    def _call_tool(self, tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
        """调用工具 API"""
        try:
            response = requests.post(
                f"{self.api_base_url}/tools/{tool_name}",
                json=params
            )
            if response.status_code == 200:
                return response.json()
            else:
                return {
                    "status": "error",
                    "message": f"工具执行失败: {response.status_code}",
                    "details": response.text
                }
        except Exception as e:
            return {
                "status": "error",
                "message": str(e)
            }
    
    def process_user_input(self, user_input: str) -> str:
        """处理用户输入 - 支持多任务"""
        print(f"\n👤 用户: {user_input}")
        
        # 记录对话历史
        self.conversation_history.append({
            "role": "user",
            "content": user_input,
            "timestamp": datetime.now().isoformat()
        })
        
        # 步骤 1: 让 LLM 理解用户意图并选择工具
        tools_context = self._format_tools_context()
        llm_response = self.llm.call(user_input, tools_context)
        print(f"\n🤖 LLM 分析: {llm_response[:300]}...")
        
        # 步骤 2: 解析 LLM 响应获取工具和参数
        tool_action = self._parse_llm_response(llm_response)
        
        if not tool_action:
            response_text = f"我理解了: {user_input}\n但我需要直接的指示来调用工具。"
            self.conversation_history.append({
                "role": "assistant",
                "content": response_text,
                "timestamp": datetime.now().isoformat()
            })
            return response_text
        
        # 处理多任务情况
        if "tasks" in tool_action:
            print(f"\n🔀 检测到多任务流程: {len(tool_action['tasks'])} 个任务")
            dependencies = tool_action.get("dependencies", [])
            tasks = tool_action["tasks"]
            
            # 执行任务
            results = []
            for i, task in enumerate(tasks):
                tool_name = task.get("tool")
                tool_params = task.get("params", {})
                
                print(f"\n[Task {i+1}/{len(tasks)}] 🔧 工具: {tool_name}")
                print(f"  📋 参数: {tool_params}")
                
                # 调用工具
                tool_result = self._call_tool(tool_name, tool_params)
                results.append({
                    "task_id": i,
                    "tool": tool_name,
                    "params": tool_params,
                    "result": tool_result
                })
                print(f"  ✅ 结果: {tool_result.get('message', 'OK')}")
            
            # 生成最终响应（多任务版）
            final_prompt = (
                f"用户请求: {user_input}\n\n"
                f"执行了以下任务:\n"
            )
            for r in results:
                final_prompt += f"- 工具 {r['tool']}: {json.dumps(r['result'].get('message', '完成'), ensure_ascii=False)}\n"
            
            final_prompt += "\n请用中文总结这些操作的结果，并给出有用的建议。"
            final_response = self.llm.call(final_prompt)
            
            self.conversation_history.append({
                "role": "assistant",
                "content": final_response,
                "timestamp": datetime.now().isoformat()
            })
            
            return final_response
        
        # 处理单任务情况
        if "tool" not in tool_action:
            response_text = f"我理解了: {user_input}\n但我需要直接的指示来调用工具。"
            self.conversation_history.append({
                "role": "assistant",
                "content": response_text,
                "timestamp": datetime.now().isoformat()
            })
            return response_text
        
        tool_name = tool_action["tool"]
        tool_params = tool_action.get("params", {})
        
        print(f"\n🔧 选定工具: {tool_name}")
        print(f"📋 工具参数: {tool_params}")
        
        # 步骤 3: 调用工具
        tool_result = self._call_tool(tool_name, tool_params)
        print(f"\n✅ 工具结果: {json.dumps(tool_result, ensure_ascii=False, indent=2)}")
        
        # 步骤 4: 让 LLM 生成最终响应
        final_prompt = (
            f"用户请求: {user_input}\n"
            f"调用的工具: {tool_name}\n"
            f"工具返回结果: {json.dumps(tool_result, ensure_ascii=False)}\n\n"
            f"请用中文总结结果,并给出有用的建议。"
        )
        final_response = self.llm.call(final_prompt)
        
        self.conversation_history.append({
            "role": "assistant",
            "content": final_response,
            "timestamp": datetime.now().isoformat()
        })
        
        return final_response
    
    def get_conversation_history(self) -> List[Dict[str, Any]]:
        """获取对话历史"""
        return self.conversation_history

# ============ 主程序 ============
if __name__ == "__main__":
    import os
    from dotenv import load_dotenv
    
    load_dotenv()
    
    # 选择 LLM 方案
    print("━" * 60)
    print("🍽️  餐厅预订 Agent - LangGraph POC")
    print("━" * 60)
    print("\n选择 LLM 方案:")
    print("1. Ollama (本地, 需要先运行 ollama serve)")
    print("2. Anthropic Claude (需要 API Key)")
    print("3. DeepSeek (需要 API Key)")
    
    choice = input("\n请选择 [1/2/3]: ").strip()
    
    if choice == "1":
        llm_type = "ollama"
        api_key = None
    elif choice == "2":
        llm_type = "anthropic"
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            api_key = input("请输入 Anthropic API Key: ").strip()
    elif choice == "3":
        llm_type = "deepseek"
        api_key = os.getenv("DEEPSEEK_API_KEY")
        if not api_key:
            api_key = input("请输入 DeepSeek API Key: ").strip()
    else:
        print("无效选择,使用默认 Ollama")
        llm_type = "ollama"
        api_key = None
    
    try:
        # 初始化 LLM 和 Agent
        llm = LLMClient(api_type=llm_type, api_key=api_key)
        agent = RestaurantAgent(llm)
        
        print("\n✓ Agent 初始化成功！")
        print("━" * 60)
        print("📝 输入 'quit' 或 'exit' 退出\n")
        
        # 交互循环
        while True:
            user_input = input(">>> ").strip()
            
            if not user_input:
                continue
            
            if user_input.lower() in ["quit", "exit", "q"]:
                print("\n👋 再见！")
                break
            
            try:
                response = agent.process_user_input(user_input)
                print(f"\n🤖 助手: {response}\n")
            except Exception as e:
                print(f"\n❌ 错误: {str(e)}\n")
                print("💡 提示: 确保 API 服务器正在运行 (python api_server.py)\n")
    
    except Exception as e:
        print(f"\n❌ 初始化失败: {str(e)}\n")
        print("💡 快速修复:")
        print("  1. 如果使用 Ollama,请先运行: ollama serve")
        print("  2. 如果使用 Anthropic,请设置 ANTHROPIC_API_KEY 环境变量")
        print("  3. 如果使用 DeepSeek,请设置 DEEPSEEK_API_KEY 环境变量")
