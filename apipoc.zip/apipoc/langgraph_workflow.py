"""
LangGraph驱动的有状态Agent工作流

支持复杂的多工具组合工作流，包括：
- 状态管理
- 条件分支
- 循环
- 错误处理
- 工具间的数据流动
"""

import json
from typing import Any, Dict, List, Callable, Optional
from datetime import datetime, timedelta
from dataclasses import dataclass, field, asdict
from enum import Enum

# ============ State 定义 ============
@dataclass
class AgentState:
    """Agent工作流状态"""
    # 基础信息
    user_id: str
    user_phone: str
    
    # 工作流信息
    workflow_type: str              # booking, cancellation, shopping等
    current_step: int = 0
    max_steps: int = 20
    
    # 用户输入和意图
    user_input: str = ""
    intent: str = ""
    
    # 执行状态
    executed_nodes: List[str] = field(default_factory=list)
    node_results: Dict[str, Any] = field(default_factory=dict)
    
    # 工具调用记录
    tool_calls: List[Dict] = field(default_factory=list)
    tool_errors: List[str] = field(default_factory=list)
    
    # 状态标志
    is_success: bool = False
    error_message: str = ""
    
    # 上下文数据（动态）
    context: Dict[str, Any] = field(default_factory=dict)


# ============ Node 定义 ============
class Node:
    """工作流节点"""
    
    def __init__(
        self,
        name: str,
        fn: Callable[[AgentState], AgentState],
        description: str = ""
    ):
        self.name = name
        self.fn = fn
        self.description = description
    
    def execute(self, state: AgentState) -> AgentState:
        """执行节点"""
        print(f"\n▶ 执行Node: {self.name}")
        if self.description:
            print(f"  说明: {self.description}")
        
        state.executed_nodes.append(self.name)
        state.current_step += 1
        
        try:
            result = self.fn(state)
            print(f"✅ {self.name} 完成")
            return result
        except Exception as e:
            print(f"❌ {self.name} 失败: {str(e)}")
            state.error_message = str(e)
            state.tool_errors.append(f"{self.name}: {str(e)}")
            raise


# ============ Edge 定义 ============
class Edge:
    """节点间的连接和路由"""
    
    def __init__(
        self,
        source: str,
        target: str,
        condition: Optional[Callable[[AgentState], bool]] = None,
        label: str = ""
    ):
        self.source = source
        self.target = target
        self.condition = condition or (lambda state: True)
        self.label = label
    
    def should_execute(self, state: AgentState) -> bool:
        """判断是否应该执行这条边"""
        return self.condition(state)


# ============ Graph 定义 ============
class Graph:
    """工作流图"""
    
    def __init__(self, name: str = "DefaultGraph"):
        self.name = name
        self.nodes: Dict[str, Node] = {}
        self.edges: List[Edge] = []
        self.entry_point: Optional[str] = None
        self.end_points: List[str] = []
    
    def add_node(self, name: str, fn: Callable, description: str = ""):
        """添加节点"""
        self.nodes[name] = Node(name, fn, description)
        return self
    
    def add_edge(
        self,
        source: str,
        target: str,
        condition: Optional[Callable] = None,
        label: str = ""
    ):
        """添加有向边"""
        edge = Edge(source, target, condition, label)
        self.edges.append(edge)
        return self
    
    def set_entry_point(self, node_name: str):
        """设置入口节点"""
        self.entry_point = node_name
        return self
    
    def add_end_point(self, node_name: str):
        """添加出口节点"""
        self.end_points.append(node_name)
        return self
    
    def _get_next_nodes(self, current_node: str, state: AgentState) -> List[str]:
        """获取下一个可执行的节点"""
        next_nodes = []
        for edge in self.edges:
            if edge.source == current_node and edge.should_execute(state):
                next_nodes.append(edge.target)
        return next_nodes
    
    def execute(self, state: AgentState) -> AgentState:
        """执行整个工作流"""
        print("\n" + "="*70)
        print(f"🚀 开始执行工作流: {self.name}")
        print("="*70)
        
        current_nodes = [self.entry_point] if self.entry_point else []
        visited = set()
        
        while current_nodes:
            next_batch = []
            
            for node_name in current_nodes:
                # 防止重复执行和无限循环
                if node_name in visited:
                    continue
                
                if state.current_step >= state.max_steps:
                    state.error_message = "超出最大步骤数"
                    break
                
                try:
                    node = self.nodes[node_name]
                    state = node.execute(state)
                    visited.add(node_name)
                    
                    # 获取下一个节点
                    next_nodes = self._get_next_nodes(node_name, state)
                    next_batch.extend(next_nodes)
                    
                except Exception as e:
                    print(f"⚠️  节点执行出错，停止工作流")
                    break
            
            current_nodes = next_batch
        
        print("\n" + "="*70)
        print(f"✅ 工作流执行完成")
        print(f"   已执行节点: {' → '.join(state.executed_nodes)}")
        print(f"   步骤数: {state.current_step}")
        print("="*70 + "\n")
        
        return state


# ============ 工具调用模拟 ============
def mock_call_tool(tool_name: str, params: Dict[str, Any]) -> Dict[str, Any]:
    """模拟工具调用"""
    
    if tool_name == "get_booking_history":
        phone = params.get("phone")
        return {
            "status": "success",
            "bookings": [
                {
                    "id": "BK202603271900",
                    "restaurant": "金牌川菜馆",
                    "date": "2026-03-28",
                    "time": "19:00",
                    "people_count": 4,
                    "created_at": "2026-03-27"
                },
                {
                    "id": "BK202603261200",
                    "restaurant": "精品粤菜",
                    "date": "2026-03-27",
                    "time": "12:00",
                    "people_count": 2,
                    "created_at": "2026-03-26"
                }
            ]
        }
    
    elif tool_name == "cancel_booking":
        booking_id = params.get("booking_id")
        return {
            "status": "success",
            "message": f"预定 {booking_id} 已取消",
            "cancelled_at": datetime.now().isoformat()
        }
    
    elif tool_name == "send_sms":
        phone = params.get("phone")
        message = params.get("message")
        return {
            "status": "success",
            "phone": phone,
            "message_length": len(message),
            "sent_at": datetime.now().isoformat()
        }
    
    elif tool_name == "search_products":
        query = params.get("query")
        return {
            "status": "success",
            "results": [
                {
                    "id": "PROD001",
                    "name": "iPhone 15 Pro",
                    "price": 999,
                    "rating": 4.8
                },
                {
                    "id": "PROD002",
                    "name": "iPhone 15",
                    "price": 799,
                    "rating": 4.7
                },
                {
                    "id": "PROD003",
                    "name": "iPhone 14 Pro",
                    "price": 699,
                    "rating": 4.5
                }
            ]
        }
    
    elif tool_name == "get_user_addresses":
        return {
            "status": "success",
            "addresses": [
                {"id": "ADDR001", "address": "北京市朝阳区XXX街道", "is_default": True},
                {"id": "ADDR002", "address": "北京市海淀区YYY街道", "is_default": False}
            ]
        }
    
    elif tool_name == "process_payment":
        return {
            "status": "success",
            "transaction_id": f"TXN{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "amount": params.get("amount"),
            "paid_at": datetime.now().isoformat()
        }
    
    elif tool_name == "create_order":
        return {
            "status": "success",
            "order_id": f"ORD{datetime.now().strftime('%Y%m%d%H%M%S')}",
            "created_at": datetime.now().isoformat()
        }
    
    return {"status": "error", "message": f"Unknown tool: {tool_name}"}


# ============ 工作流示例 ============

# 示例 1: 取消预订工作流
def create_cancellation_workflow() -> Graph:
    """创建取消预订工作流"""
    
    graph = Graph("CancellationWorkflow")
    
    # Node 1: 查询预定历史
    def node_get_bookings(state: AgentState) -> AgentState:
        user_phone = state.context.get("user_phone")
        print(f"  📞 查询电话: {user_phone} 的预定记录")
        
        result = mock_call_tool("get_booking_history", {"phone": user_phone})
        state.context["bookings"] = result.get("bookings", [])
        state.node_results["get_bookings"] = result
        print(f"  📋 找到 {len(state.context['bookings'])} 条预定记录")
        return state
    
    # Node 2: 选择要取消的预定
    def node_select_booking(state: AgentState) -> AgentState:
        bookings = state.context.get("bookings", [])
        if not bookings:
            raise Exception("没有预定记录")
        
        booking = bookings[0]  # 选择最新的
        state.context["booking_to_cancel"] = booking
        print(f"  ⭐ 选定要取消的预定: {booking['restaurant']} ({booking['date']} {booking['time']})")
        return state
    
    # Node 3: 执行取消
    def node_cancel_booking(state: AgentState) -> AgentState:
        booking = state.context["booking_to_cancel"]
        print(f"  🚫 执行取消操作...")
        
        result = mock_call_tool("cancel_booking", {"booking_id": booking["id"]})
        state.context["cancellation_result"] = result
        state.node_results["cancel_booking"] = result
        return state
    
    # Node 4: 发送取消通知
    def node_send_notification(state: AgentState) -> AgentState:
        user_phone = state.context["user_phone"]
        booking = state.context["booking_to_cancel"]
        
        message = f"✅ 您已成功取消在{booking['restaurant']}的预定（{booking['date']} {booking['time']}, {booking['people_count']}人）。如有需要可重新预订。"
        print(f"  📱 发送短信: {message[:30]}...")
        
        result = mock_call_tool("send_sms", {"phone": user_phone, "message": message})
        state.node_results["send_sms"] = result
        return state
    
    # 构建图
    graph.add_node("get_bookings", node_get_bookings, "查询用户的预定历史")
    graph.add_node("select_booking", node_select_booking, "选择要取消的预定")
    graph.add_node("cancel_booking", node_cancel_booking, "执行取消操作")
    graph.add_node("send_notification", node_send_notification, "发送取消通知短信")
    
    # 添加边
    graph.add_edge("get_bookings", "select_booking", label="总是执行")
    graph.add_edge("select_booking", "cancel_booking", label="总是执行")
    graph.add_edge("cancel_booking", "send_notification", label="总是执行")
    
    # 设置入口和出口
    graph.set_entry_point("get_bookings")
    graph.add_end_point("send_notification")
    
    return graph


# 示例 2:购物工作流
def create_shopping_workflow() -> Graph:
    """创建在线购物工作流"""
    
    graph = Graph("ShoppingWorkflow")
    
    # Node 1: 搜索商品
    def node_search_products(state: AgentState) -> AgentState:
        query = state.context.get("search_query", "iPhone 15")
        print(f"  🔍 搜索商品: {query}")
        
        result = mock_call_tool("search_products", {"query": query})
        state.context["search_results"] = result.get("results", [])
        state.node_results["search_products"] = result
        print(f"  📦 搜到 {len(state.context['search_results'])} 个结果")
        return state
    
    # Node 2: 选择商品
    def node_select_product(state: AgentState) -> AgentState:
        results = state.context.get("search_results", [])
        if not results:
            raise Exception("没有搜索结果")
        
        product = results[0]  # 选择第一个（或根据价格/评分选择）
        state.context["selected_product"] = product
        print(f"  ⭐ 选定商品: {product['name']} (¥{product['price']})")
        return state
    
    # Node 3: 查询收货地址
    def node_get_addresses(state: AgentState) -> AgentState:
        user_id = state.user_id
        print(f"  🏠 查询用户 {user_id} 的收货地址")
        
        result = mock_call_tool("get_user_addresses", {})
        state.context["addresses"] = result.get("addresses", [])
        state.node_results["get_addresses"] = result
        print(f"  📍 找到 {len(state.context['addresses'])} 个地址")
        return state
    
    # Node 4: 选择地址
    def node_select_address(state: AgentState) -> AgentState:
        addresses = state.context.get("addresses", [])
        if not addresses:
            raise Exception("没有地址信息")
        
        address = next((a for a in addresses if a.get("is_default")), addresses[0])
        state.context["shipping_address"] = address
        print(f"  ✓ 选定收货地址: {address['address']}")
        return state
    
    # Node 5: 处理支付
    def node_process_payment(state: AgentState) -> AgentState:
        product = state.context.get("selected_product")
        amount = product.get("price", 0)
        print(f"  💳 处理支付: ¥{amount}")
        
        result = mock_call_tool("process_payment", {"amount": amount})
        state.context["payment_result"] = result
        state.node_results["process_payment"] = result
        state.context["transaction_id"] = result.get("transaction_id")
        print(f"  ✅ 支付成功 (交易号: {result.get('transaction_id')})")
        return state
    
    # Node 6: 创建订单
    def node_create_order(state: AgentState) -> AgentState:
        product = state.context.get("selected_product")
        address = state.context.get("shipping_address")
        print(f"  📋 创建订单...")
        
        result = mock_call_tool("create_order", {
            "product_id": product.get("id"),
            "address": address.get("address"),
            "transaction_id": state.context.get("transaction_id")
        })
        state.context["order_id"] = result.get("order_id")
        state.node_results["create_order"] = result
        print(f"  📦 订单已创建 (订单号: {result.get('order_id')})")
        return state
    
    # Node 7: 发送确认短信
    def node_send_confirmation(state: AgentState) -> AgentState:
        user_phone = state.user_phone
        product = state.context.get("selected_product")
        order_id = state.context.get("order_id")
        transaction_id = state.context.get("transaction_id")
        
        message = f"✅订单确认！商品: {product['name']}, 价格: ¥{product['price']}, 订单号: {order_id}, 交易号: {transaction_id}"
        print(f"  📱 发送确认短信...")
        
        result = mock_call_tool("send_sms", {"phone": user_phone, "message": message})
        state.node_results["send_confirmation"] = result
        return state
    
    # 构建图
    graph.add_node("search_products", node_search_products, "搜索商品")
    graph.add_node("select_product", node_select_product, "选择商品")
    graph.add_node("get_addresses", node_get_addresses, "查询收货地址")
    graph.add_node("select_address", node_select_address, "选择地址")
    graph.add_node("process_payment", node_process_payment, "处理支付")
    graph.add_node("create_order", node_create_order, "创建订单")
    graph.add_node("send_confirmation", node_send_confirmation, "发送确认短信")
    
    # 添加边
    graph.add_edge("search_products", "select_product")
    graph.add_edge("select_product", "get_addresses")
    graph.add_edge("get_addresses", "select_address")
    graph.add_edge("select_address", "process_payment")
    graph.add_edge("process_payment", "create_order")
    graph.add_edge("create_order", "send_confirmation")
    
    # 设置入口和出口
    graph.set_entry_point("search_products")
    graph.add_end_point("send_confirmation")
    
    return graph


# ============ 主程序 ============
if __name__ == "__main__":
    print("\n" + "="*70)
    print("🚀 LangGraph工作流演示")
    print("="*70)
    
    # 示例 1: 取消预订
    print("\n【场景 1】取消餐厅预订")
    print("-" * 70)
    
    cancellation_graph = create_cancellation_workflow()
    state1 = AgentState(
        user_id="user123",
        user_phone="13800138000",
        workflow_type="cancellation",
        user_input="我要取消预定",
        intent="cancel_booking",
        context={"user_phone": "13800138000"}
    )
    
    result1 = cancellation_graph.execute(state1)
    print(f"\n📊 执行结果:")
    print(f"   ✅ 成功: {len(result1.node_results) > 0}")
    print(f"   📋 执行的节点: {' → '.join(result1.executed_nodes)}")
    print(f"   ⚙️  工具调用数: {len(result1.node_results)}")
    
    # 示例 2: 购物
    print("\n\n【场景 2】在线购物流程")
    print("-" * 70)
    
    shopping_graph = create_shopping_workflow()
    state2 = AgentState(
        user_id="user456",
        user_phone="13900000000",
        workflow_type="shopping",
        user_input="帮我买iPhone 15，寄到我家",
        intent="shopping",
        context={"search_query": "iPhone 15"}
    )
    
    result2 = shopping_graph.execute(state2)
    print(f"\n📊 执行结果:")
    print(f"   ✅ 成功: {len(result2.node_results) > 0}")
    print(f"   📋 执行的节点: {' → '.join(result2.executed_nodes)}")
    print(f"   ⚙️  工具调用数: {len(result2.node_results)}")
    
    # 总结
    print("\n" + "="*70)
    print("✨ 演示总结")
    print("="*70)
    print("""
    ✅ 实现的功能:
    
    1. 状态管理 (AgentState)
       - 完整的工作流状态追踪
       - 节点执行历史
       - 工具调用记录
    
    2. 有向无环图 (DAG)
       - 节点和边的组织
       - 条件路由
       - 执行流程控制
    
    3. 工具组合
       - 多个工具的顺序调用
       - 工具间的数据流动
       - 结果聚合
    
    4. 复杂工作流
       - 取消预订 (查询→选择→取消→通知)
       - 在线购物 (搜索→选择→地址→支付→订单→通知)
    
    🎯 后续可扩展:
    
    1. 条件分支
       - 基于支付结果决定是否继续
       - 是否需要用户确认
    
    2. 错误处理
       - 支付失败时重试
       - 任何步骤失败都可回滚
    
    3. 循环
       - allow users to select multiple products
       - 重复支付流程
    
    4. 动态工作流
       - 根据用户输入生成工作流
       - 自动推荐最优执行路径
    """)
    print("="*70 + "\n")
