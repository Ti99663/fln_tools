# 餐厅预订 Agent - 架构设计

## 核心问题

### 1. 参数提取改进
**当前问题**：LLM参数提取效果差
**解决方案**：
- 改进prompting：提供清晰的JSON schema示例
- 多级验证：LLM提取 → Code补充 → 缺失默认值
- 参数验证反馈循环

### 2. 多任务处理
**核心需求**：
- 识别用户请求中的多个任务
- 分析任务间的依赖关系
- 生成任务执行计划（DAG图）
- 支持并行执行、顺序执行、条件执行

**示例场景**：
```
用户输入: "先帮我搜索中关村的川菜，然后查一下搜到的第一家餐厅今天有没有空位"
分解结果:
  Task 1: search_restaurants(location="中关村", cuisine_type="川菜")
  Task 2: check_availability(restaurant_name=<Task1.result[0].name>, date="2026-03-27")
  关系: Task2 依赖于 Task1

用户输入: "帮我同时查金牌川菜馆和精品粤菜今天的空位"
分解结果:
  Task 1: check_availability(restaurant_name="金牌川菜馆", date="2026-03-27")
  Task 2: check_availability(restaurant_name="精品粤菜", date="2026-03-27")
  关系: Task1 和 Task2 可并行执行
```

## 工作流程

```
用户输入
  ↓
[Step 1] 意图识别 (Intent Recognition)
  - 使用LLM识别用户意图
  - 初步选择可能的工具
  ↓
[Step 2] 任务分解 (Task Decomposition)
  - 检测多任务情况
  - 解析任务依赖关系
  - 生成任务执行计划（DAG）
  ↓
[Step 3] 参数提取 (Parameter Extraction)
  - LLM提取结构化参数（使用improved prompting）
  - Code补充缺失参数
  - 参数验证
  ↓
[Step 4] 执行计划优化 (Plan Optimization)
  - 分析任务间的依赖
  - 确定并行或顺序执行
  - 生成最优执行顺序
  ↓
[Step 5] 执行 (Execution)
  - 按执行计划执行任务
  - 处理任务结果
  - 返回最终响应
  ↓
用户响应
```

## 参数提取的Prompting改进

### 当前问题
```
LLM输出: "Sure! Here's an updated version... [不相关内容]"
参数: {}
```

### 改进策略
1. **严格的JSON格式要求**
   ```
   你必须返回以下JSON格式，不要返回任何其他文本：
   {
     "tool": "tool_name",
     "params": {
       "key": "value"
     }
   }
   ```

2. **提供示例**
   ```
   示例1：用户说"帮我在中关村找川菜馆"
   返回: {"tool": "search_restaurants", "params": {"location": "中关村", "cuisine_type": "川菜"}}
   
   示例2：用户说"查金牌川菜馆今天有没有空位"
   返回: {"tool": "check_availability", "params": {"restaurant_name": "金牌川菜馆", "date": "2026-03-27"}}
   ```

3. **参数枚举**
   ```
   工具参数说明：
   - search_restaurants: location(地点), cuisine_type(菜系，可选)
   - check_availability: restaurant_name(餐厅名), date(日期，格式YYYY-MM-DD)
   - make_booking: restaurant_name, date, time(HH:MM), people_count(整数), customer_name, phone
   ```

## 多任务处理框架

### 任务依赖关系类型
1. **无依赖**（可并行）：各任务独立执行
2. **顺序依赖**：Task B 需要 Task A 的结果
3. **条件依赖**：Task B 只在 Task A 满足条件时执行
4. **管道依赖**：Task A 的输出是 Task B 的输入

### 检测方法
```python
# 方法1：关键词检测
if "然后" in user_input:  # 顺序依赖
if "同时" in user_input or "分别" in user_input:  # 可并行
if "如果" in user_input:  # 条件依赖

# 方法2：LLM分析
prompt = """
分析用户请求中的任务依赖关系。用户可能有多个任务需要执行。
返回JSON格式：
{
  "tasks": [
    {"id": 1, "tool": "...", "params": {...}},
    {"id": 2, "tool": "...", "params": {...}}
  ],
  "dependencies": [
    {"from": 1, "to": 2, "type": "sequential"}
  ]
}
"""
```

## POC实现计划

### Phase 1: 参数提取改进 (已完成)
- ✅ 固定的regex提取逻辑
- ⏳ 改进LLM提示词
- ⏳ 多级验证流程

### Phase 2: 单任务处理 (进行中)
- 工具选择
- 参数提取
- 执行和返回

### Phase 3: 多任务识别 (后续)
- 任务分解
- 依赖关系分析
- 执行计划生成

### Phase 4: 执行引擎 (后续)
- DAG执行器
- 并行执行支持
- 结果聚合

## 成功指标

✅ **Phase 1 目标**：Agent能正确选择工具并提取参数
- Tool selection accuracy: 100%
- Parameter extraction: 90%+ (Code补充可达100%)

✅ **Phase 2 目标**：完整的单任务处理流程
- 工具调用成功率: 95%+
- 返回有意义的响应

🎯 **Phase 3 目标**：多任务识别
- 正确识别多个任务: 85%+
- 正确分析依赖关系: 80%+

🎯 **Phase 4 目标**：并行执行
- 正确的执行顺序: 100%
- 并行任务同时执行: ✓

