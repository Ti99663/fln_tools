# 🍽️ 餐厅预订 Agent - LangGraph POC

基于 **LangGraph** 框架，集成 **API 工具管理系统**，支持**多个免费 LLM 接口**的智能餐厅预订助手。

## 📋 项目概述

### 核心特性

✅ **LangGraph 框架** - 图式 Agent 架构，支持复杂工作流  
✅ **API 工具管理** - RESTful API 服务，易于扩展和维护  
✅ **多个免费 LLM** - Ollama、Anthropic、DeepSeek  
✅ **自然语言理解** - LLM 自动解析用户意图并选择工具  
✅ **状态管理** - 完整的对话历史和 Agent 状态跟踪  

### 系统架构

```
┌────────────────────────────────────────────────────┐
│            用户交互层 (run_poc.py)                  │
│  • 用户输入处理                                    │
│  • 交互式会话管理                                  │
└────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────┐
│        LangGraph Agent 层 (agent.py)               │
│  • 用户意图分析 (LLM)                              │
│  • 工具选择和参数提取 (LLM)                        │
│  • 结果总结 (LLM)                                  │
└────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────┐
│         工具 API 层 (api_server.py)                 │
│  • search_restaurants - 搜索餐厅                   │
│  • check_availability - 查询可用时间               │
│  • make_booking - 预订餐厅                         │
│  • get_booking_history - 查询预订历史              │
└────────────────────────────────────────────────────┘
                        ↓
┌────────────────────────────────────────────────────┐
│         数据存储层 (模拟数据库)                      │
│  • 餐厅信息库                                      │
│  • 预订记录库                                      │
└────────────────────────────────────────────────────┘
```

## 🚀 快速开始

### 前置要求

```bash
# Python 3.8+
python --version
```

### 方案 A: 使用 Ollama (⭐ 推荐用于演示)

**优点:** 完全本地、无需注册、无 API 调用限制

#### 1. 安装 Ollama

- **Windows**: https://ollama.ai/download
- **Mac**: https://ollama.ai/download  
- **Linux**: https://ollama.ai/download

#### 2. 启动 Ollama 服务

```bash
ollama serve
```

#### 3. 下载模型

```bash
# 下载中文支持的模型 (推荐)
ollama pull llama2-chinese

# 或者下载其他模型
ollama pull neural-chat
ollama pull mistral
```

#### 4. 安装项目依赖

```bash
cd d:\临时文件\apipoc
pip install -r requirements.txt
```

#### 5. 运行 POC

```bash
python run_poc.py
```

然后选择 `1` (Ollama)

---

### 方案 B: 使用 Anthropic Claude

**优点:** API 质量高、功能强大  
**缺点:** 需要 API Key（可免费试用）

#### 1. 获取 API Key

访问 https://console.anthropic.com/account/keys

- 点击 "Create Key"
- 复制生成的 API Key

#### 2. 设置环境变量

**Windows:**
```cmd
set ANTHROPIC_API_KEY=your-api-key-here
```

**Linux/Mac:**
```bash
export ANTHROPIC_API_KEY=your-api-key-here
```

#### 3. 安装依赖

```bash
cd d:\临时文件\apipoc
pip install -r requirements.txt
```

#### 4. 运行 POC

```bash
python run_poc.py
```

然后选择 `2` (Anthropic)

---

### 方案 C: 使用 DeepSeek

**优点:** 国内服务、性价比高  
**缺点:** 需要 API Key

#### 1. 获取 API Key

访问 https://platform.deepseek.com

- 申请账号
- 获取 API Key

#### 2. 设置环境变量

**Windows:**
```cmd
set DEEPSEEK_API_KEY=your-api-key-here
```

**Linux/Mac:**
```bash
export DEEPSEEK_API_KEY=your-api-key-here
```

#### 3. 运行 POC

```bash
python run_poc.py
```

然后选择 `3` (DeepSeek)

---

## 📁 项目结构

```
apipoc/
├── api_server.py          # FastAPI 工具服务器
├── agent.py               # LangGraph Agent 实现
├── langgraph_agent.py     # 高级 LangGraph 实现
├── run_poc.py             # 完整 POC 入口
├── requirements.txt       # Python 依赖
├── .env.example          # 环境变量模板
└── README.md             # 本文件
```

## 💡 使用示例

### 示例 1: 搜索餐厅

```
>>> 我想在中关村找一家四川菜餐厅

🤖 助手: 我为您找到了 1 家符合条件的餐厅：
1. 金牌川菜馆
   - 位置: 中关村
   - 菜系: 四川菜
   - 评分: 4.8/5.0
   - 电话: 010-12345678
```

### 示例 2: 查询可用时间

```
>>> 请查一下金牌川菜馆今天7点有没有位置

🤖 助手: 金牌川菜馆在今天 19:00 有 5 个空位可预订。
建议您尽快预订。
```

### 示例 3: 预订餐厅

```
>>> 帮我预订金牌川菜馆，今天19点，4人，我叫张三，电话13800138000

🤖 助手: 预订成功！
预订号: BK20240325193045789
餐厅: 金牌川菜馆
时间: 今天 19:00
人数: 4 人
客户: 张三
```

## 🔧 工具 API 参考

### 1. 搜索餐厅 (search_restaurants)

**请求:**
```json
{
  "location": "中关村",
  "cuisine_type": "四川菜"
}
```

**响应:**
```json
{
  "status": "success",
  "count": 1,
  "restaurants": [
    {
      "name": "金牌川菜馆",
      "location": "中关村",
      "cuisine": "四川菜",
      "rating": 4.8,
      "phone": "010-12345678"
    }
  ]
}
```

### 2. 查询可用时间 (check_availability)

**请求:**
```json
{
  "restaurant_name": "金牌川菜馆",
  "date": "2024-12-25"
}
```

**响应:**
```json
{
  "status": "success",
  "restaurant": "金牌川菜馆",
  "date": "2024-12-25",
  "available_times": [
    {"time": "11:00", "available_tables": 5},
    {"time": "12:00", "available_tables": 3}
  ]
}
```

### 3. 预订餐厅 (make_booking)

**请求:**
```json
{
  "restaurant_name": "金牌川菜馆",
  "date": "2024-12-25",
  "time": "19:00",
  "people_count": 4,
  "customer_name": "张三",
  "phone": "13800138000"
}
```

**响应:**
```json
{
  "status": "success",
  "message": "预订成功",
  "booking_id": "BK20240325193045789",
  "booking_details": {...}
}
```

### 4. 查询预订历史 (get_booking_history)

**请求:**
```json
{
  "customer_phone": "13800138000"
}
```

**响应:**
```json
{
  "status": "success",
  "phone": "13800138000",
  "count": 2,
  "bookings": [...]
}
```

## 🏗️ LangGraph 架构详解

Agent 执行流程采用图式设计，包含以下节点：

```
START
  ↓
[LLM 分析] - 理解用户意图，选择工具
  ↓
[工具执行] - 调用 API 工具
  ↓
[LLM 总结] - 生成自然语言响应
  ↓
[END]
```

### 状态转移

- **LLM 分析**: 成功 → 工具执行 | 失败 → 错误处理
- **工具执行**: 成功 → LLM 总结 | 失败 → 错误处理  
- **LLM 总结**: 成功 → 结束

## 🐛 故障排除

### 问题 1: Ollama 连接失败

```
错误: 无法连接到 Ollama。请先运行: ollama serve
```

**解决方案:**
```bash
# 启动 Ollama 服务
ollama serve

# 如果端口被占用，检查进程
netstat -ano | findstr :11434
```

### 问题 2: API 服务器启动失败

```
错误: API 服务器启动失败
```

**检查 8001 端口:**
```bash
# Windows
netstat -ano | findstr :8001

# 杀死占用进程
taskkill /PID <PID> /F
```

### 问题 3: API Key 错误

```
错误: 无效的 API Key
```

**检查环境变量:**
```bash
# Windows
echo %ANTHROPIC_API_KEY%

# Linux/Mac
echo $ANTHROPIC_API_KEY
```

或直接在提示中输入 API Key

## 📊 监控和日志

### 查看 API 日志

API 服务器运行时会显示详细的请求日志：

```
INFO:     127.0.0.1:52743 - "POST /tools/search_restaurants HTTP/1.1" 200 OK
INFO:     127.0.0.1:52744 - "POST /tools/make_booking HTTP/1.1" 200 OK
```

### 查看 Agent 状态

启用详细输出：

```python
agent.verbose = True
```

## 🚀 扩展指南

### 添加新工具

#### 1. 在 API 服务器中添加端点

```python
@app.post("/tools/your_tool_name")
async def your_tool(request: YourRequest):
    # 实现逻辑
    return {"status": "success", "result": ...}
```

#### 2. 注册工具定义

```python
AVAILABLE_TOOLS.append({
    "name": "your_tool_name",
    "description": "工具描述",
    "parameters": {
        "param1": {"type": "string", "description": "参数1"}
    }
})
```

工具会自动在 Agent 中可用！

### 修改模型或提示词

在 `agent.py` 中修改：

```python
def _format_tools_context(self) -> str:
    tools_text = "你是专业的 XXX 助手。\n\n"
    # ... 自定义提示词
```

## 📝 API 文档

查看 Swagger UI:

```
http://localhost:8001/docs
```

## ⚡ 性能优化

### 使用更小的模型

如果 Ollama 运行缓慢，使用更轻量的模型：

```bash
ollama pull neural-chat
ollama pull orca-mini
```

### 增加超时时间

在 `agent.py` 中调整：

```python
self.request_timeout = 60  # 秒
```

## 📄 许可证

MIT License

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

## ❓ FAQ

**Q: 可以离线运行吗？**  
A: 是的，使用 Ollama 方案完全离线运行。

**Q: 支持什么语言？**  
A: 主要支持中文，但其他语言的 LLM 应该也能工作。

**Q: 可以添加实际的数据库吗？**  
A: 可以，将 API 服务器中的 RESTAURANTS_DB 替换为真实数据库连接。

**Q: 如何部署到生产环境？**  
A: 使用 Docker 容器化，配合 Gunicorn 部署 API 服务器。

---

**最后更新:** 2024 年 3 月  
**版本:** 1.0 POC
