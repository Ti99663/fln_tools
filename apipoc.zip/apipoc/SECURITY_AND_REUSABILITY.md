# 工具系统的安全性和可复用性设计

## 核心问题分析

### 问题1：工具的数据源耦合
```python
# ❌ 不好的做法：工具硬编码数据库逻辑
class GetBookingHistoryTool:
    def execute(self):
        db = MySQLConnection("localhost", "restaurant_db")
        result = db.query("SELECT * FROM bookings WHERE user_id = ?")
        return result
```

问题：
- 工具与MySQL紧耦合
- 无法切换数据源（PostgreSQL、MongoDB等）
- 无法复用到其他上下文

### 问题2：权限控制缺失
```python
# ❌ 不好的做法：没有权限检查
def cancel_booking(booking_id):
    db.update("DELETE FROM bookings WHERE id = ?", booking_id)
    # 任何人都可以删除任何预定！
```

问题：
- 没有权限检查
- 数据安全隐患
- 无法审计操作

---

## 解决方案：4层架构

```
┌─────────────────────────────────────┐
│         Agent / LangGraph            │
│  （调用工具，不关心实现细节）         │
└────────────┬────────────────────────┘
             │
┌────────────▼────────────────────────┐
│     Tool Context & Security         │
│  - 用户信息                          │
│  - 权限检查                          │
│  - 審計日志                          │
└────────────┬────────────────────────┘
             │
┌────────────▼────────────────────────┐
│     Generic Tool Interface           │
│  - 参数化配置                        │
│  - 动作分类                          │
│  - 守卫条件                          │
└────────────┬────────────────────────┘
             │
┌────────────▼────────────────────────┐
│     Data Source Abstraction          │
│  - 数据库连接池                      │
│  - 查询引擎                          │
│  - 缓存层                            │
└─────────────────────────────────────┘
```

---

## 具体设计

### Layer 1: 工具上下文（Tool Context）

```python
from enum import Enum
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from datetime import datetime

class ActionType(Enum):
    """工具的动作类型"""
    READ = "read"         # 查询操作
    CREATE = "create"     # 创建操作
    UPDATE = "update"     # 更新操作
    DELETE = "delete"     # 删除操作
    EXECUTE = "execute"   # 执行操作

class PermissionLevel(Enum):
    """权限级别"""
    ADMIN = 100
    MODERATOR = 50
    USER = 10
    GUEST = 0

@dataclass
class User:
    """用户信息"""
    id: str
    name: str
    role: str
    permission_level: PermissionLevel
    
class ToolContext:
    """工具执行的上下文"""
    
    def __init__(self, user: User, data_source_config: Dict[str, Any] = None):
        self.user = user
        self.data_source_config = data_source_config or {}
        self.audit_log: List[Dict] = []
        self.request_id = self._generate_request_id()
    
    def _generate_request_id(self) -> str:
        """生成请求ID用于追踪"""
        import uuid
        return str(uuid.uuid4())
    
    def log_action(self, action: ActionType, resource: str, status: str, details: Dict = None):
        """记录操作日志"""
        self.audit_log.append({
            "timestamp": datetime.now().isoformat(),
            "request_id": self.request_id,
            "user_id": self.user.id,
            "action": action.value,
            "resource": resource,
            "status": status,
            "details": details or {}
        })
    
    def has_permission(self, permission_level: PermissionLevel) -> bool:
        """检查权限"""
        return self.user.permission_level.value >= permission_level.value
```

### Layer 2: 通用工具接口

```python
from abc import ABC, abstractmethod

class GenericTool(ABC):
    """通用工具基类"""
    
    def __init__(self, 
                 name: str,
                 action_type: ActionType,
                 required_permission: PermissionLevel,
                 metadata: ToolMetadata):
        self.name = name
        self.action_type = action_type
        self.required_permission = required_permission
        self.metadata = metadata
    
    def execute(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行工具的入口方法"""
        try:
            # 步骤1：权限检查
            if not self._check_permission(context):
                context.log_action(
                    self.action_type, 
                    self.name, 
                    "denied",
                    {"reason": "insufficient_permission"}
                )
                raise PermissionError(
                    f"用户 {context.user.id} 没有权限执行 {self.name}"
                )
            
            # 步骤2：输入验证
            self._validate_inputs(inputs)
            
            # 步骤3：前置条件检查
            self._check_preconditions(context, inputs)
            
            # 步骤4：执行业务逻辑
            result = self._execute_impl(context, inputs)
            
            # 步骤5：记录成功
            context.log_action(
                self.action_type,
                self.name,
                "success",
                {"input_keys": list(inputs.keys())}
            )
            
            return result
            
        except Exception as e:
            # 记录失败
            context.log_action(
                self.action_type,
                self.name,
                "error",
                {"error": str(e)}
            )
            raise
    
    def _check_permission(self, context: ToolContext) -> bool:
        """检查权限"""
        return context.has_permission(self.required_permission)
    
    def _validate_inputs(self, inputs: Dict[str, Any]) -> None:
        """验证输入参数"""
        required_keys = set(self.metadata.input_schema.keys())
        provided_keys = set(inputs.keys())
        
        missing_keys = required_keys - provided_keys
        if missing_keys:
            raise ValueError(f"缺少必需的参数: {missing_keys}")
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """检查前置条件（可被子类覆盖）"""
        pass
    
    @abstractmethod
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """实际执行的业务逻辑（由子类实现）"""
        pass
```

### Layer 3: 数据源抽象

```python
class DataSource(ABC):
    """数据源抽象接口"""
    
    @abstractmethod
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        """执行查询"""
        pass
    
    @abstractmethod
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """插入数据"""
        pass
    
    @abstractmethod
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        """更新数据"""
        pass
    
    @abstractmethod
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        """删除数据"""
        pass

# MySQL 实现
class MySQLDataSource(DataSource):
    def __init__(self, host: str, user: str, password: str, database: str):
        self.connection_url = f"mysql+pymysql://{user}:{password}@{host}/{database}"
    
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        # 使用 SQLAlchemy 或其他库
        pass
    
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        pass
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        pass
    
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        pass

# PostgreSQL 实现
class PostgreSQLDataSource(DataSource):
    def __init__(self, host: str, user: str, password: str, database: str):
        self.connection_url = f"postgresql://{user}:{password}@{host}/{database}"
    
    def query(self, sql: str, params: List[Any]) -> List[Dict]:
        pass
    
    def insert(self, table: str, data: Dict[str, Any]) -> int:
        pass
    
    def update(self, table: str, data: Dict[str, Any], where: Dict[str, Any]) -> int:
        pass
    
    def delete(self, table: str, where: Dict[str, Any]) -> int:
        pass

# API 实现（如果数据来自外部API）
class APIDataSource(DataSource):
    def __init__(self, api_url: str, api_key: str):
        self.api_url = api_url
        self.api_key = api_key
    
    def query(self, endpoint: str, params: Dict[str, Any]) -> List[Dict]:
        # 调用 API
        pass
    
    def insert(self, endpoint: str, data: Dict[str, Any]) -> int:
        pass
    
    def update(self, endpoint: str, data: Dict[str, Any]) -> int:
        pass
    
    def delete(self, endpoint: str, data: Dict[str, Any]) -> int:
        pass
```

### Layer 4: 具体工具实现

```python
class GetBookingHistoryTool(GenericTool):
    """查询预订历史的可复用工具"""
    
    def __init__(self):
        metadata = ToolMetadata(
            name="get_booking_history",
            description="查询用户的预订记录",
            category=ToolCategory.QUERY,
            input_schema={
                "user_id": "str",
                "table_name": "str",  # 参数化表名
                "filter_conditions": "Dict"  # 查询条件
            },
            output_schema={"bookings": "List[Dict]"}
        )
        super().__init__(
            name="get_booking_history",
            action_type=ActionType.READ,
            required_permission=PermissionLevel.USER,  # 普通用户可查询
            metadata=metadata
        )
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """前置条件：用户只能查询自己的数据"""
        user_id = inputs.get("user_id")
        
        # 检查：普通用户只能查询自己的数据
        if context.user.permission_level != PermissionLevel.ADMIN:
            if user_id != context.user.id:
                raise PermissionError(
                    f"用户 {context.user.id} 无权查询其他用户的数据"
                )
    
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行查询"""
        user_id = inputs["user_id"]
        table_name = inputs.get("table_name", "bookings")
        filter_conditions = inputs.get("filter_conditions", {})
        
        # 获取数据源
        data_source = self._get_data_source(context)
        
        # 构建查询条件
        where_clause = {"user_id": user_id}
        where_clause.update(filter_conditions)
        
        # 执行查询
        sql = f"SELECT * FROM {table_name} WHERE user_id = ?"
        result = data_source.query(sql, [user_id])
        
        return {
            "bookings": result,
            "count": len(result)
        }
    
    def _get_data_source(self, context: ToolContext) -> DataSource:
        """根据配置获取数据源"""
        config = context.data_source_config
        source_type = config.get("type", "mysql")
        
        if source_type == "mysql":
            return MySQLDataSource(
                host=config["host"],
                user=config["user"],
                password=config["password"],
                database=config["database"]
            )
        elif source_type == "postgresql":
            return PostgreSQLDataSource(
                host=config["host"],
                user=config["user"],
                password=config["password"],
                database=config["database"]
            )
        elif source_type == "api":
            return APIDataSource(
                api_url=config["api_url"],
                api_key=config["api_key"]
            )
        else:
            raise ValueError(f"不支持的数据源类型: {source_type}")


class CancelBookingTool(GenericTool):
    """取消预订的工具"""
    
    def __init__(self):
        metadata = ToolMetadata(
            name="cancel_booking",
            description="取消一个预订",
            category=ToolCategory.ACTION,
            input_schema={
                "booking_id": "str",
                "table_name": "str",
                "user_id": "str"
            },
            output_schema={"success": "bool"}
        )
        super().__init__(
            name="cancel_booking",
            action_type=ActionType.DELETE,
            required_permission=PermissionLevel.USER,
            metadata=metadata
        )
    
    def _check_preconditions(self, context: ToolContext, inputs: Dict[str, Any]) -> None:
        """前置条件检查"""
        booking_id = inputs["booking_id"]
        user_id = inputs["user_id"]
        
        # 步骤1：检查预订是否存在和属于该用户
        data_source = self._get_data_source(context)
        result = data_source.query(
            "SELECT * FROM bookings WHERE id = ? AND user_id = ?",
            [booking_id, user_id]
        )
        
        if not result:
            raise ValueError(
                f"预订 {booking_id} 不存在或不属于用户 {user_id}"
            )
        
        booking = result[0]
        
        # 步骤2：检查预订状态（例如，不能取消已完成的预订）
        if booking.get("status") == "completed":
            raise ValueError("无法取消已完成的预订")
        
        if booking.get("status") == "cancelled":
            raise ValueError("预订已被取消")
        
        # 步骤3：权限检查（只有所有者或管理员可以取消）
        if context.user.id != user_id and context.user.permission_level != PermissionLevel.ADMIN:
            raise PermissionError(
                f"用户 {context.user.id} 无权取消其他用户的预订"
            )
    
    def _execute_impl(self, context: ToolContext, inputs: Dict[str, Any]) -> Dict[str, Any]:
        """执行取消"""
        booking_id = inputs["booking_id"]
        table_name = inputs.get("table_name", "bookings")
        
        data_source = self._get_data_source(context)
        
        # 更新预订状态为 'cancelled'
        affected_rows = data_source.update(
            table_name,
            {"status": "cancelled", "cancelled_at": datetime.now().isoformat()},
            {"id": booking_id}
        )
        
        return {
            "success": affected_rows > 0,
            "booking_id": booking_id,
            "affected_rows": affected_rows
        }
    
    def _get_data_source(self, context: ToolContext) -> DataSource:
        """根据配置获取数据源"""
        config = context.data_source_config
        source_type = config.get("type", "mysql")
        
        if source_type == "mysql":
            return MySQLDataSource(
                host=config["host"],
                user=config["user"],
                password=config["password"],
                database=config["database"]
            )
        elif source_type == "postgresql":
            return PostgreSQLDataSource(
                host=config["host"],
                user=config["user"],
                password=config["password"],
                database=config["database"]
            )
        else:
            raise ValueError(f"不支持的数据源类型: {source_type}")
```

---

## 使用示例

```python
# 步骤1：创建工具上下文
user = User(
    id="user_123",
    name="张三",
    role="customer",
    permission_level=PermissionLevel.USER
)

context = ToolContext(
    user=user,
    data_source_config={
        "type": "mysql",
        "host": "localhost",
        "user": "root",
        "password": "password",
        "database": "restaurant_db"
    }
)

# 步骤2：创建工具
get_history_tool = GetBookingHistoryTool()
cancel_tool = CancelBookingTool()

# 步骤3：执行工具
try:
    # 查询自己的预订历史（允许）
    result = get_history_tool.execute(context, {
        "user_id": "user_123",
        "table_name": "bookings",
        "filter_conditions": {"status": "confirmed"}
    })
    print("✓ 查询成功:", result)
    
except PermissionError as e:
    print("✗ 权限错误:", e)

# 步骤4：查看审计日志
for log in context.audit_log:
    print(f"[{log['timestamp']}] {log['action']} {log['resource']} - {log['status']}")
```

---

## 权限矩阵

| 操作 | 自己的数据 | 他人的数据 | 权限 |
|------|----------|----------|------|
| READ (查询) | ✓ | ✗ | USER |
| CREATE | ✓ | ✗ | USER |
| UPDATE | ✓ | ✗ | USER |
| DELETE | ✓ | ✗ | MODERATOR |
| READ (任何) | ✓ | ✓ | ADMIN |
| DELETE (任何) | ✓ | ✓ | ADMIN |

---

## 集成到 LangGraph

```python
def execute_tool_with_context(
    state: AgentState,
    tool_registry: ToolRegistry,
    context: ToolContext
) -> AgentState:
    """在 LangGraph 中执行工具"""
    
    workflow = state["workflow"]
    completed = set(state["completed_steps"])
    
    # 获取可执行的节点
    executable_nodes = workflow.get_executable_nodes(completed)
    
    for node_name in executable_nodes:
        tool = tool_registry.get_tool(node_name)
        
        if not tool:
            state["errors"][node_name] = f"工具 '{node_name}' 未找到"
            continue
        
        try:
            # 关键：传入 context
            inputs = state["outputs"].get(node_name, {})
            result = tool.execute(context, inputs)
            
            state["outputs"][node_name] = result
            state["completed_steps"].append(node_name)
            
        except PermissionError as e:
            state["errors"][node_name] = f"权限错误: {str(e)}"
        except Exception as e:
            state["errors"][node_name] = str(e)
    
    # 将审计日志添加到 state
    state["audit_logs"] = context.audit_log
    
    return state
```

---

## 总结

### ✅ 解决的问题

1. **数据源解耦**
   - 工具不再关心具体数据库
   - 支持 MySQL、PostgreSQL、API 等多种数据源
   - 通过配置灵活切换

2. **权限控制**
   - 前置条件检查
   - 权限级别控制
   - 资源所有权验证

3. **可审计性**
   - 所有操作都有日志记录
   - 包含时间戳、用户、请求ID
   - 便于追踪和调查

4. **可复用性**
   - 工具是参数化的
   - 可以在不同场景复用
   - 数据源配置动态传入

### 🎯 架构优势

- **关注点分离**：Agent 不用关心权限和数据源
- **易于测试**：可以用 Mock DataSource 测试
- **易于扩展**：添加新的权限级别或数据源类型
- **安全性高**：前置条件和权限检查保证数据安全

