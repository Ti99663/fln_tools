# LangGraph 高级抽象架构设计

## 核心问题

❌ **传统方式（低层抽象）**：
```python
if user_input == "取消预定":
    # 调用查询工具
    history = call_tool("get_booking_history")
    if history:
        # 调用取消工具
        result = call_tool("cancel_booking", history[0])
        if result.success:
            # 调用短信工具
            call_tool("send_sms", "预定已取消")
```
问题：
- 硬编码逻辑混乱
- 每个新需求都要改agent代码
- 条件判断爆炸式增长
- 难以维护和扩展

✅ **高级抽象方式（本文档提议）**：
```python
# 用户请求 → 自动生成工作流 → 执行 → 完成
# Agent不关心具体细节，只关心"意图"和"状态"
```

---

## 架构设计：`工作流引擎` + `高级抽象`

### 第一层：工具注册系统（Tool Registry）

```python
# 一次性注册所有工具，包括元信息
tool_registry = ToolRegistry()

tool_registry.register(
    name="get_booking_history",
    description="查询用户的所有预定记录",
    category="query",           # 查询类工具
    output_type="List[Booking]",
    preconditions=[],           # 无前置条件
    success_indicators=["booking_id", "status"],
)

tool_registry.register(
    name="cancel_booking",
    description="取消一个具体的预定",
    category="action",          # 动作类工具
    input_type="booking_id",
    preconditions=["get_booking_history"],  # 需要先查询
    side_effects=["send_notification"],     # 会触发通知
)

tool_registry.register(
    name="send_sms",
    description="发送短信给用户",
    category="notification",    # 通知类工具
    input_type="message",
    preconditions=[],
    is_optional=True,           # 可选工具
)
```

### 第二层：意图识别系统（Intent System）

```python
# 定义高级意图，而不是具体操作
class Intent:
    """代表用户的高级意图"""
    pass

class CancelBookingIntent(Intent):
    """取消预定的意图"""
    description = "用户想要取消已有的预定"
    required_outputs = ["booking_id"]  # 需要哪些信息
    optional_outputs = ["reason"]      # 可选信息

class SearchAndBuyIntent(Intent):
    """搜索并购买商品"""
    description = "用户想要搜索并购买商品"
    required_outputs = ["product_id", "address", "payment_method"]
    optional_outputs = ["coupon_code"]

# Agent只需识别意图，不需要写具体逻辑
intent = llm.recognize_intent(user_input)
# 返回: CancelBookingIntent
```

### 第三层：工作流生成系统（Workflow Generator）

```python
# 根据意图和工具注册表，自动生成工作流
class WorkflowGenerator:
    def generate(self, intent: Intent, tool_registry: ToolRegistry) -> Workflow:
        """
        根据意图和可用工具，生成最优的执行工作流
        """
        # 输入：Intent
        # 处理：智能搜索最优路径
        # 输出：Workflow DAG
        
        workflow = Workflow()
        
        # 步骤1：收集满足意图所需的所有工具
        required_tools = self._find_tools_for_intent(intent)
        
        # 步骤2：分析依赖关系，生成DAG
        dag = self._analyze_dependencies(required_tools)
        
        # 步骤3：添加数据流转
        workflow.add_node("start", start_node)
        for tool in dag.topological_sort():
            workflow.add_node(tool.name, tool_node)
            workflow.add_edges(tool.preconditions, tool.name)
        workflow.add_node("end", end_node)
        
        return workflow

# 使用示例
intent = CancelBookingIntent()
workflow = generator.generate(intent, tool_registry)
result = workflow.execute()
```

### 第四层：LangGraph 状态机

```python
from langgraph.graph import StateGraph, END

# 定义全局状态
class AgentState(TypedDict):
    """Agent的全局状态"""
    user_input: str
    intent: Intent
    workflow: Workflow
    current_step: int
    outputs: Dict[str, Any]  # 各工具的输出
    errors: List[str]
    messages: List[Message]

# 构建LangGraph
workflow = StateGraph(AgentState)

# 节点1：意图识别
def recognize_intent_node(state: AgentState) -> AgentState:
    """识别用户意图"""
    state["intent"] = llm.recognize_intent(state["user_input"])
    return state

# 节点2：工作流生成
def generate_workflow_node(state: AgentState) -> AgentState:
    """根据意图生成工作流"""
    state["workflow"] = workflow_generator.generate(
        state["intent"], 
        tool_registry
    )
    return state

# 节点3：执行工作流的任意一步
def execute_workflow_step(state: AgentState) -> AgentState:
    """执行工作流中的下一步"""
    workflow = state["workflow"]
    next_steps = workflow.get_executable_steps(state["outputs"])
    
    for step in next_steps:
        tool = tool_registry.get(step)
        inputs = state["outputs"]  # 从之前的步骤中获取输入
        try:
            result = tool.call(inputs)
            state["outputs"][step] = result
        except Exception as e:
            state["errors"].append(f"{step}: {str(e)}")
    
    state["current_step"] += 1
    return state

# 条件边：是否还有步骤需要执行
def should_continue(state: AgentState) -> str:
    workflow = state["workflow"]
    next_steps = workflow.get_executable_steps(state["outputs"])
    if next_steps:
        return "execute"  # 继续执行
    else:
        return "end"      # 完成

# 构建图
workflow.add_node("recognize", recognize_intent_node)
workflow.add_node("generate", generate_workflow_node)
workflow.add_node("execute", execute_workflow_step)

workflow.add_edge("START", "recognize")
workflow.add_edge("recognize", "generate")
workflow.add_edge("generate", "execute")
workflow.add_conditional_edges(
    "execute",
    should_continue,
    {
        "execute": "execute",
        "end": END
    }
)

agent = workflow.compile()
```

---

## 关键创新点

### 1. **意图 vs 工具**

| 维度 | 工具层 | 意图层 |
|------|-------|--------|
| 抽象级别 | 低（具体） | 高（语义） |
| 维护频率 | 经常变动 | 较稳定 |
| 示例 | get_booking_history, cancel_booking | CancelBookingIntent |
| 添加成本 | 低（只注册工具） | 中（定义意图类） |

**好处**：
- 新工具不需要改Agent逻辑
- 只需注册工具，系统自动组合
- 添加新意图时，复用现有工具

### 2. **自动工作流生成**

```
输入：Intent
处理流程：
  1. 从意图的required_outputs找到能产生这些输出的工具
  2. 这些工具的preconditions找到更多需要的工具
  3. 递归直到没有新的依赖
  4. 拓扑排序生成最优顺序

输出：可执行的DAG
```

示例：
```
用户：取消我的预定
      ↓
意图：CancelBookingIntent (需要 booking_id)
      ↓
搜索工具：什么工具能产生 booking_id？
      ↓
找到：get_booking_history → 产生 booking_id
      ↓
继续分析：cancel_booking 需要 booking_id ✓
      ↓
最终工作流：
  [get_booking_history] → [cancel_booking] → [send_sms]
```

### 3. **高级抽象的LangGraph节点**

```python
# 传统方式（细节导向）
@workflow.add_node
def handle_cancel(state):
    if state["step"] == 1:
        return query_bookings(state)
    elif state["step"] == 2:
        return cancel_booking(state)
    elif state["step"] == 3:
        return send_sms(state)

# 高级方式（意图导向）
@workflow.add_node
def execute_workflow(state):
    """通用的工作流执行节点"""
    # 不关心具体是什么业务
    # 只关心"执行工作流的下一步"
    next_steps = state["workflow"].get_executable_steps(state["outputs"])
    for step in next_steps:
        state["outputs"][step] = execute_tool(step, state["outputs"])
    return state
```

### 4. **灵活的工具组合**

工具被通用的工作流引擎调用，而不是硬编码在某个分支中：

```python
# 一个工具可以被不同的意图组合使用

tool: send_sms

# 在多个工作流中被使用：
- CancelBookingIntent workflow
- PurchaseCompleteIntent workflow  
- PasswordResetIntent workflow
- OrderShippedIntent workflow
```

---

## 完整示例：2种场景对比

### 场景1：取消预定

#### 步骤 1～3：前置设置（一次性）

```python
# 1. 注册工具（一次性）
tool_registry.register(
    name="get_booking_history",
    category="query",
    preconditions=[],
    success_indicators=["booking_id"]
)

tool_registry.register(
    name="cancel_booking",
    category="action",
    preconditions=["get_booking_history"],
    side_effects=["send_sms"]
)

tool_registry.register(
    name="send_sms",
    category="notification",
    preconditions=[],
    is_optional=True
)

# 2. 定义意图类（一次性）
class CancelBookingIntent(Intent):
    description = "用户想要取消预定"
    required_outputs = ["booking_id"]

# 3. 配置LangGraph（一次性）
workflow_graph = StateGraph(AgentState)
workflow_graph.add_node("execute_workflow", execute_workflow_node)
# ... 其他节点配置
```

#### 步骤 4～N：运行时（每次用户请求）

```python
# 用户输入
user_input = "我想取消我的预定"

# → Agent自动处理（无需修改代码）
state = {
    "user_input": user_input,
    "intent": None,
    "workflow": None,
    "outputs": {},
    "errors": []
}

# LangGraph 执行
result = agent.invoke(state)

# 结果
# state["intent"] = CancelBookingIntent
# state["workflow"] = DAG(get_booking_history → cancel_booking → send_sms)
# state["outputs"] = {
#     "get_booking_history": [Booking(...), ...],
#     "cancel_booking": {"success": True},
#     "send_sms": {"message_id": "..."}
# }
```

### 场景2：新增功能 - 修改预定

#### 传统方式（坏例子）

```python
# ❌ 需要修改Agent核心代码
def process_user_input(user_input):
    if "取消" in user_input:
        # 取消逻辑... 100行
    elif "修改" in user_input:  # 新增
        # 修改逻辑... 150行
    elif "查询" in user_input:
        # 查询逻辑... 50行
    # ... 越来越多的elif
```

#### 高级抽象方式（好例子）

```python
# ✅ 只需添加新意图和工具，Agent代码零改动

# 步骤1：定义新意图
class ModifyBookingIntent(Intent):
    description = "用户想要修改已有的预定"
    required_outputs = ["booking_id", "new_time"]
    optional_outputs = ["reason"]

# 步骤2：注册新工具（或复用现有）
tool_registry.register(
    name="modify_booking",
    category="action",
    preconditions=["get_booking_history"],
    side_effects=["send_sms"]
)

# 完成！Agent自动支持新功能，无需任何修改
```

---

## 架构对比

### 传统架构（Node-based）
```
Agent Code
├── if intent == "cancel":
│   ├── query_booking()
│   ├── cancel_booking()
│   └── send_sms()
├── elif intent == "modify":
│   ├── query_booking()
│   ├── modify_booking()
│   └── send_sms()
├── elif intent == "search":
│   └── search_restaurants()
└── ... 更多intent

问题：
- 硬编码增多时不可维护
- 每个新功能都需要人工设计流程
- Agent代码爆炸
```

### 高级抽象架构（Flow-based）
```
Agent Core (核心，不变)
├── recognize_intent()     ← LLM调用
├── generate_workflow()    ← 自动生成
└── execute_workflow()     ← 通用执行

Tool Registry (工具集，易扩展)
├── Tool A (preconditions: [], side_effects: [B, C])
├── Tool B (preconditions: [A], side_effects: [D])
├── Tool C (preconditions: [A], side_effects: [E])
├── Tool D (preconditions: [B], side_effects: [])
└── ... 更多工具

Intent Registry (意图集，易扩展)
├── IntentA (required_outputs: [X, Y], workflow: auto-generated)
├── IntentB (required_outputs: [Y, Z], workflow: auto-generated)
└── ... 更多意图

优点：
- Agent核心代码稳定
- 添加新工具 = 注册 + 定义元数据
- 自动组合优化
```

---

## 实现策略：分阶段开发

### Phase 1：基础工具系统（本周）
```python
✅ ToolRegistry 类
✅ 工具的元数据定义
✅ 基本的依赖分析算法
```

### Phase 2：意图和工作流生成（下周）
```python
✅ Intent 基类
✅ WorkflowGenerator 类
✅ DAG 生成和拓扑排序
```

### Phase 3：集成LangGraph（下周～）
```python
✅ LangGraph 节点设计
✅ State 字典设计
✅ 条件边处理
```

### Phase 4：多工具协调（后续）
```python
✅ 工具间的数据映射
✅ 错误恢复和重试
✅ 日志和追踪
```

---

## 核心代码框架

```python
# tools.py - 工具系统
class Tool:
    def __init__(self, name, description, category):
        self.name = name
        self.description = description
        self.category = category
        self.preconditions = []
        self.side_effects = []
    
    def call(self, inputs):
        # 调用具体的工具实现
        pass

class ToolRegistry:
    def register(self, tool):
        # 注册工具
        pass
    
    def get_tools_for_output(self, output_name):
        # 找出能产生某个输出的所有工具
        pass

# intents.py - 意图系统
class Intent:
    required_outputs = []
    optional_outputs = []
    
class CancelBookingIntent(Intent):
    required_outputs = ["booking_id"]

# workflow.py - 工作流系统
class WorkflowGenerator:
    def generate(self, intent, tool_registry):
        # 根据意图生成工作流DAG
        pass

# langgraph_agent.py - LangGraph集成
def create_agent(tool_registry, intent_registry):
    graph = StateGraph(AgentState)
    # ... 节点定义
    return graph.compile()
```

---

## 关键好处总结

| 方面 | 传统方式 | 高级抽象方式 |
|------|---------|---------|
| **新功能添加** | 修改Agent代码 | 注册工具 + 定义意图 |
| **维护成本** | 随需求线性增长 | 相对稳定 |
| **代码复杂度** | O(n²) n=功能数 | O(n) |
| **工具复用** | 困难（硬编码） | 容易（自动组合） |
| **测试** | 每个功能单独测试 | 测试工具 + 工作流生成 |
| **学习曲线** | 陡峭（各种if-else） | 平缓（意图 + 工具系统） |
| **自动优化** | 无 | 有（自动排序依赖） |

---

## 总结

✨ **核心理念**：

> 不让Agent写"怎么做"（具体逻辑），只让它管"做什么"（意图声明）。
> 
> 工作流自动生成，工具自动组合，代码自动演进。

这样做的结果是：
- 🎯 **Agent代码稳定**：不因新功能而改动
- 🔧 **扩展成本低**：只需注册新工具和意图
- 🚀 **自动优化**：工作流生成器自动找最优路径
- 📚 **易于维护**：所有逻辑集中在工具和意图层

