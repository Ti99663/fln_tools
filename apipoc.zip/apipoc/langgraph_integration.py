"""
将安全工具系统集成到 LangGraph 中

展示如何使用安全上下文在多工具工作流中执行
"""

from typing import Annotated, Any, Dict, List, TypedDict, Optional
from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
import json

# ============================================================================
# 导入安全工具系统
# ============================================================================

from secure_tools import (
    ToolContext, User, PermissionLevel, ActionType,
    GetUserBookingsTool, CancelBookingTool,
    DataSource, MockMySQLDataSource
)


# ============================================================================
# LangGraph 集成
# ============================================================================

class WorkflowState(TypedDict):
    """工作流状态"""
    user: User
    context: ToolContext
    tools_executed: List[str]
    current_step: str
    results: Dict[str, Any]
    error: Optional[str]
    operation: str
    next_node: str


def create_secure_workflow():
    """创建一个安全的、多工具工作流"""
    
    workflow = StateGraph(WorkflowState)
    
    # ========================================================================
    # 步骤1：初始化安全上下文
    # ========================================================================
    def init_context_node(state: WorkflowState) -> WorkflowState:
        """初始化安全上下文"""
        print("\n📋 [步骤1] 初始化安全上下文")
        print("-" * 60)
        
        user = state["user"]
        print(f"  用户: {user.name} ({user.role})")
        print(f"  权限级别: {user.permission_level.name}")
        
        # 创建安全上下文
        context = ToolContext(
            user=user,
            data_source_config={
                "type": "mysql",
                "host": "localhost",
                "user": "root",
                "password": "password",
                "database": "restaurant_db"
            }
        )
        
        state["context"] = context
        state["current_step"] = "context_initialized"
        
        return state
    
    # ========================================================================
    # 步骤2：执行查询工具
    # ========================================================================
    def execute_get_bookings_node(state: WorkflowState) -> WorkflowState:
        """执行查询用户预订"""
        print("\n📖 [步骤2] 执行查询用户预订")
        print("-" * 60)
        
        try:
            tool = GetUserBookingsTool()
            result = tool.execute(state["context"], {
                "user_id": state["user"].id
            })
            
            print(f"  ✓ 成功: {result['count']} 个预订")
            
            state["results"]["bookings"] = result
            state["tools_executed"].append("get_bookings")
            state["current_step"] = "get_bookings_done"
            
            # 如果没有预订，直接返回
            if result["count"] == 0:
                state["error"] = "没有找到预订"
                return state
            
        except Exception as e:
            print(f"  ✗ 错误: {e}")
            state["error"] = str(e)
            return state
        
        return state
    
    # ========================================================================
    # 步骤3：决策：是否要取消预订？
    # ========================================================================
    def decision_node(state: WorkflowState) -> WorkflowState:
        """判断是否可以继续取消"""
        print("\n🔄 [步骤3] 决策：是否可以取消预订？")
        print("-" * 60)
        
        # 检查是否是取消操作
        if state.get("operation") == "cancel":
            print(f"  ✓ 用户要求取消预订，尝试执行...")
            state["next_node"] = "cancel_path"
        else:
            print(f"  ✓ 只查询，不取消")
            state["next_node"] = "complete_path"
        
        return state
    
    # ========================================================================
    # 步骤4：执行取消工具
    # ========================================================================
    def execute_cancel_booking_node(state: WorkflowState) -> WorkflowState:
        """执行取消预订"""
        print("\n🗑️  [步骤4] 执行取消预订")
        print("-" * 60)
        
        try:
            # 获取第一个预订的ID
            bookings = state["results"]["bookings"]["bookings"]
            if not bookings:
                state["error"] = "没有预订可取消"
                return state
            
            booking_id = bookings[0]["id"]
            print(f"  取消预订: {booking_id}")
            
            tool = CancelBookingTool()
            result = tool.execute(state["context"], {
                "booking_id": booking_id,
                "user_id": state["user"].id
            })
            
            print(f"  ✓ 成功: {result['affected_rows']} 条记录受影响")
            
            state["results"]["cancellation"] = result
            state["tools_executed"].append("cancel_booking")
            state["current_step"] = "cancel_done"
            
        except PermissionError as e:
            print(f"  ✗ 权限错误: {e}")
            state["error"] = f"权限不足: {e}"
        except ValueError as e:
            print(f"  ✗ 业务错误: {e}")
            state["error"] = f"业务错误: {e}"
        except Exception as e:
            print(f"  ✗ 其他错误: {e}")
            state["error"] = str(e)
        
        return state
    
    # ========================================================================
    # 步骤5：打印审计日志
    # ========================================================================
    def print_audit_node(state: WorkflowState) -> WorkflowState:
        """打印审计日志"""
        print("\n" + "="*60)
        state["context"].print_audit_log()
        print("="*60)
        
        return state
    
    # ========================================================================
    # 步骤6：完成
    # ========================================================================
    def complete_node(state: WorkflowState) -> WorkflowState:
        """完成工作流"""
        print("\n✅ [步骤6] 工作流完成")
        print("-" * 60)
        print(f"  执行的工具: {', '.join(state['tools_executed'])}")
        if state.get("error"):
            print(f"  错误: {state['error']}")
        
        return state
    
    # ========================================================================
    # 定义图的节点和边
    # ========================================================================
    
    workflow.add_node("init_context", init_context_node)
    workflow.add_node("get_bookings", execute_get_bookings_node)
    workflow.add_node("decide", decision_node)
    workflow.add_node("cancel_booking", execute_cancel_booking_node)
    workflow.add_node("print_audit", print_audit_node)
    workflow.add_node("complete", complete_node)
    
    # 定义边
    workflow.add_edge(START, "init_context")
    workflow.add_edge("init_context", "get_bookings")
    workflow.add_edge("get_bookings", "print_audit")
    workflow.add_edge("print_audit", "decide")
    
    # 条件边
    workflow.add_conditional_edges(
        "decide",
        lambda state: state.get("next_node", "complete_path"),
        {
            "cancel_path": "cancel_booking",
            "error_path": "complete",
            "complete_path": "complete"
        }
    )
    
    workflow.add_edge("cancel_booking", "print_audit")
    workflow.add_edge("complete", END)
    
    return workflow.compile()


# ============================================================================
# 演示
# ============================================================================

def demo_scenario_1():
    """场景1：普通用户查询自己的预订"""
    print("\n" + "="*80)
    print("【场景1】普通用户查询自己的预订")
    print("="*80)
    
    graph = create_secure_workflow()
    
    user = User(
        id="user_123",
        name="张三",
        role="customer",
        permission_level=PermissionLevel.USER
    )
    
    initial_state: WorkflowState = {
        "user": user,
        "context": None,
        "tools_executed": [],
        "current_step": "start",
        "results": {},
        "error": None,
        "operation": "query",  # 只查询
        "next_node": "complete_path"
    }
    
    # 执行工作流
    final_state = graph.invoke(initial_state)
    
    print(f"\n✨ 最终状态:")
    print(f"  执行的工具: {final_state['tools_executed']}")
    print(f"  错误: {final_state['error'] or '无'}")


def demo_scenario_2():
    """场景2：用户尝试取消预订但权限不足"""
    print("\n" + "="*80)
    print("【场景2】用户尝试取消预订但权限不足")
    print("="*80)
    
    graph = create_secure_workflow()
    
    user = User(
        id="user_123",
        name="张三",
        role="customer",
        permission_level=PermissionLevel.USER
    )
    
    initial_state: WorkflowState = {
        "user": user,
        "context": None,
        "tools_executed": [],
        "current_step": "start",
        "results": {},
        "error": None,
        "operation": "cancel",  # 要取消
        "next_node": "cancel_path"
    }
    
    final_state = graph.invoke(initial_state)
    
    print(f"\n✨ 最终状态:")
    print(f"  执行的工具: {final_state['tools_executed']}")
    print(f"  错误: {final_state['error'] or '无'}")
    
    # 检查是否被正确拒绝
    if "权限不足" in (final_state['error'] or ''):
        print(f"  ✓ 被正确拒绝：权限不足")


def demo_scenario_3():
    """场景3：主持人成功取消用户的预订"""
    print("\n" + "="*80)
    print("【场景3】主持人成功取消用户的预订")
    print("="*80)
    
    graph = create_secure_workflow()
    
    moderator = User(
        id="mod_001",
        name="王五",
        role="moderator",
        permission_level=PermissionLevel.MODERATOR
    )
    
    initial_state: WorkflowState = {
        "user": moderator,
        "context": None,
        "tools_executed": [],
        "current_step": "start",
        "results": {},
        "error": None,
        "operation": "cancel",  # 要取消
        "next_node": "cancel_path"
    }
    
    final_state = graph.invoke(initial_state)
    
    print(f"\n✨ 最终状态:")
    print(f"  执行的工具: {final_state['tools_executed']}")
    print(f"  错误: {final_state['error'] or '无'}")
    
    # 检查是否成功
    if "cancel_booking" in final_state['tools_executed']:
        print(f"  ✓ 成功取消预订")


if __name__ == "__main__":
    print("\n" + "="*80)
    print("🔗 安全工具系统与 LangGraph 集成演示")
    print("="*80)
    
    demo_scenario_1()
    demo_scenario_2()
    demo_scenario_3()
    
    print("\n" + "="*80)
    print("✨ 集成总结")
    print("="*80)
    print("""
✅ LangGraph 集成的优势：
  1. 清晰的工作流控制（init → query → decide → [cancel/complete])
  2. 条件边支持权限检查后的分支
  3. 每个步骤都有安全上下文保护
  4. 审计日志完整记录所有操作
  5. 错误处理和权限拒绝都被正确处理

🔐 安全性保证：
  - 权限检查在每个工具执行时进行
  - 前置条件验证防止非法操作
  - 所有权验证确保数据隐私
  - 审计日志供后期查证
  - 工作流层面也支持权限感知的分支

📊 支持的工作流模式：
  1. 顺序执行（查询→取消→通知）
  2. 条件执行（根据权限或数据状态）
  3. 错误处理（权限拒绝、业务错误等）
  4. 多数据源（同一工具支持多个DB配置）
""")
